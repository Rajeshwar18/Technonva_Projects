using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using CompanyManagementSystem.Models;
using CompanyManagementSystem.Models.ViewModels;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace CompanyManagementSystem.Controllers
{
    [AllowAnonymous]
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ILogger<AccountController> _logger;

        public AccountController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            ILogger<AccountController> logger)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            _logger.LogInformation("Login page accessed. ReturnUrl: {ReturnUrl}", returnUrl);
            if (!string.IsNullOrEmpty(returnUrl))
            {
                ViewData["ReturnUrl"] = returnUrl;
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel? model, string? returnUrl = null)
        {
            try
            {
                _logger.LogInformation("Login attempt started for email: {Email}", model?.Email);
                
                if (model == null)
                {
                    _logger.LogWarning("Login attempt with null model");
                    ModelState.AddModelError(string.Empty, "Invalid login attempt. Please provide your email and password.");
                    return View(model);
                }
                
                if (string.IsNullOrEmpty(model.Email))
                {
                    _logger.LogWarning("Login attempt with empty email");
                    ModelState.AddModelError(string.Empty, "Email is required.");
                    return View(model);
                }
                
                if (string.IsNullOrEmpty(model.Password))
                {
                    _logger.LogWarning("Login attempt with empty password");
                    ModelState.AddModelError(string.Empty, "Password is required.");
                    return View(model);
                }

                if (!string.IsNullOrEmpty(returnUrl))
                {
                    ViewData["ReturnUrl"] = returnUrl;
                }
                
                if (!ModelState.IsValid)
                {
                    _logger.LogWarning("Login attempt with invalid model state: {Errors}", 
                        string.Join(", ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));
                    return View(model);
                }

                // Find user by email
                var user = await _userManager.FindByEmailAsync(model.Email.Trim());
                _logger.LogInformation("User lookup result for {Email}: {Found}", model.Email, user != null);
                
                if (user == null)
                {
                    _logger.LogWarning("Login attempt for non-existent user {Email}", model.Email);
                    ModelState.AddModelError(string.Empty, "Invalid login attempt. Please check your email and password.");
                    return View(model);
                }

                // Check if user is locked out
                var isLockedOut = await _userManager.IsLockedOutAsync(user);
                _logger.LogInformation("User {Email} locked out status: {IsLockedOut}", model.Email, isLockedOut);
                
                if (isLockedOut)
                {
                    _logger.LogWarning("Login attempt for locked out user {Email}", model.Email);
                    ModelState.AddModelError(string.Empty, "This account has been locked out. Please try again later.");
                    return View(model);
                }

                // Attempt to sign in
                _logger.LogInformation("Attempting to sign in user {Email}", model.Email);
                var result = await _signInManager.PasswordSignInAsync(
                    user.UserName, // Use UserName instead of Email
                    model.Password,
                    model.RememberMe,
                    lockoutOnFailure: true);
                
                _logger.LogInformation("Sign in result for {Email}: Succeeded={Succeeded}, RequiresTwoFactor={RequiresTwoFactor}, IsLockedOut={IsLockedOut}", 
                    model.Email, result.Succeeded, result.RequiresTwoFactor, result.IsLockedOut);
                
                if (result.Succeeded)
                {
                    _logger.LogInformation("User {Email} logged in successfully", model.Email);
                    
                    // Get user roles and redirect accordingly
                    var roles = await _userManager.GetRolesAsync(user);
                    _logger.LogInformation("User {Email} roles: {Roles}", model.Email, string.Join(", ", roles));
                    
                    if (roles.Contains("Admin"))
                    {
                        _logger.LogInformation("Redirecting admin user {Email} to Admin/Index", model.Email);
                        return RedirectToAction("Index", "Admin");
                    }
                    else if (roles.Contains("Subadmin"))
                    {
                        _logger.LogInformation("Redirecting subadmin user {Email} to Subadmin/Index", model.Email);
                        return RedirectToAction("Index", "Subadmin");
                    }
                    else
                    {
                        _logger.LogInformation("Redirecting regular user {Email} to User/Index", model.Email);
                        return RedirectToAction("Index", "User");
                    }
                }
                
                if (result.RequiresTwoFactor)
                {
                    _logger.LogInformation("User {Email} requires two-factor authentication", model.Email);
                    return RedirectToAction(nameof(LoginWith2fa), new { returnUrl, model.RememberMe });
                }
                
                if (result.IsLockedOut)
                {
                    _logger.LogWarning("User account {Email} locked out", model.Email);
                    return RedirectToAction(nameof(Lockout));
                }
                else
                {
                    _logger.LogWarning("Invalid login attempt for user {Email}", model.Email);
                    ModelState.AddModelError(string.Empty, "Invalid login attempt. Please check your email and password.");
                    return View(model);
                }
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "Error during login attempt for user {Email}", model?.Email);
                ModelState.AddModelError(string.Empty, "An error occurred during login. Please try again.");
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Lockout()
        {
            return View();
        }

        [HttpGet]
        public IActionResult LoginWith2fa(bool rememberMe, string? returnUrl = null)
        {
            if (!string.IsNullOrEmpty(returnUrl))
            {
                ViewData["ReturnUrl"] = returnUrl;
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Login");
        }

        [AllowAnonymous]
        public IActionResult AccessDenied(string returnUrl = null)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }
    }
} 