using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompanyManagementSystem.Data;
using CompanyManagementSystem.Models;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace CompanyManagementSystem.Controllers
{
    [Authorize(Roles = "Admin")]
    public class CompanyDetailsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CompanyDetailsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(int id, string area = null)
        {
            var company = await _context.Companies
                .Include(c => c.HRDocuments)
                .Include(c => c.Issues)
                .Include(c => c.Employees)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;

            // If area is Marketing, return the Marketing Index view
            if (area == "Marketing")
            {
                return View("~/Views/CompanyDetails/Marketing/Index.cshtml", company);
            }
            
            // If area is Purchase, return the Purchase Index view
            if (area == "Purchase")
            {
                return View("~/Views/CompanyDetails/Purchase/Index.cshtml", company);
            }

            // If area is QC, return the QC Index view
            if (area == "QC")
            {
                return View("~/Views/CompanyDetails/QC/Index.cshtml", company);
            }

            // If area is Store, return the Store Index view
            if (area == "Store")
            {
                return View("~/Views/CompanyDetails/Store/Index.cshtml", company);
            }

            // Default behavior
            return View(company);
        }

        public async Task<IActionResult> HR(int id)
        {
            var company = await _context.Companies
                .Include(c => c.HRDocuments)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View(company);
        }

        public async Task<IActionResult> QC(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/QC.cshtml", company);
        }

        public async Task<IActionResult> DHR01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.HRDocuments.Where(d => d.Code.StartsWith("DHR01")))
                .Include(c => c.Employees)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            ViewBag.Documents = company.HRDocuments?.ToList() ?? new List<HRDocument>();
            return View("~/Views/CompanyDetails/HR/DHR01.cshtml", company);
        }

        public async Task<IActionResult> DHR02(int id)
        {
            var company = await _context.Companies
                .Include(c => c.Issues)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            ViewBag.Issues = company.Issues?.ToList() ?? new List<Issue>();
            return View("~/Views/CompanyDetails/HR/DHR02.cshtml", company);
        }

        public async Task<IActionResult> FHR01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.Employees)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            ViewBag.Employees = company.Employees?.ToList() ?? new List<Employee>();
            return View("~/Views/CompanyDetails/HR/FHR01.cshtml", company);
        }

        [HttpGet]
        public IActionResult Form(int id)
        {
            var company = _context.Companies.Find(id);
            if (company == null)
            {
                return NotFound();
            }
            return View("~/Views/CompanyDetails/HR/Form.cshtml", company);
        }

        public async Task<IActionResult> HR_PCMR03(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMR03"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/PCMR03.cshtml", company);
        }

        [HttpPost]
        public async Task<IActionResult> SaveDocument(Document document)
        {
            try
            {
                if (document.Id == 0)
                {
                    document.Date = DateTime.Now;
                    _context.Documents.Add(document);
                }
                else
                {
                    var existingDoc = await _context.Documents.FindAsync(document.Id);
                    if (existingDoc == null)
                    {
                        return NotFound();
                    }
                    existingDoc.Title = document.Title;
                    existingDoc.Version = document.Version;
                    existingDoc.Content = document.Content;
                    existingDoc.Status = document.Status;
                }

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Document saved successfully.";
                return RedirectToAction(nameof(DHR01), new { id = document.CompanyId });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error saving document: " + ex.Message;
                return RedirectToAction(nameof(DHR01), new { id = document.CompanyId });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteDocument(int id)
        {
            var document = await _context.Documents.FindAsync(id);
            if (document == null)
            {
                return NotFound();
            }

            _context.Documents.Remove(document);
            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> SaveIssue(Issue issue)
        {
            try
            {
                if (issue.Id == 0)
                {
                    issue.CreatedDate = DateTime.Now;
                    _context.Issues.Add(issue);
                }
                else
                {
                    var existingIssue = await _context.Issues.FindAsync(issue.Id);
                    if (existingIssue == null)
                    {
                        return NotFound();
                    }
                    existingIssue.Type = issue.Type;
                    existingIssue.Factor = issue.Factor;
                    existingIssue.Objective = issue.Objective;
                }

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Issue saved successfully.";
                return RedirectToAction(nameof(DHR02), new { id = issue.CompanyId });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error saving issue: " + ex.Message;
                return RedirectToAction(nameof(DHR02), new { id = issue.CompanyId });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteIssue(int id)
        {
            var issue = await _context.Issues.FindAsync(id);
            if (issue == null)
            {
                return NotFound();
            }

            _context.Issues.Remove(issue);
            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> SaveEmployee(Employee employee)
        {
            try
            {
                if (employee.Id == 0)
                {
                    _context.Employees.Add(employee);
                }
                else
                {
                    var existingEmployee = await _context.Employees.FindAsync(employee.Id);
                    if (existingEmployee == null)
                    {
                        return NotFound();
                    }
                    existingEmployee.Name = employee.Name;
                    existingEmployee.Designation = employee.Designation;
                    existingEmployee.Qualification = employee.Qualification;
                    existingEmployee.JoiningYear = employee.JoiningYear;
                    existingEmployee.Experience = employee.Experience;
                }

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Employee saved successfully.";
                return RedirectToAction(nameof(Form), new { id = employee.CompanyId });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error saving employee: " + ex.Message;
                return RedirectToAction(nameof(Form), new { id = employee.CompanyId });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            try
            {
                var employee = await _context.Employees.FindAsync(id);
                if (employee == null)
                {
                    return Json(new { success = false, message = "Employee not found" });
                }

                _context.Employees.Remove(employee);
                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> SaveEmployeeData([FromBody] EmployeeDataViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { success = false, message = "Invalid data provided." });
                }

                var company = await _context.Companies.FindAsync(model.CompanyId);
                if (company == null)
                {
                    return Json(new { success = false, message = "Company not found." });
                }

                // Remove existing employees for this company
                var existingEmployees = await _context.Employees
                    .Where(e => e.CompanyId == model.CompanyId)
                    .ToListAsync();
                _context.Employees.RemoveRange(existingEmployees);

                // Add new employees
                foreach (var employeeData in model.Employees)
                {
                    var employee = new Employee
                    {
                        CompanyId = model.CompanyId,
                        Sr = employeeData.Sr,
                        Name = employeeData.Name,
                        Designation = employeeData.Designation,
                        Qualification = employeeData.Qualification,
                        JoiningYear = employeeData.JoiningYear,
                        Experience = employeeData.Experience,
                        Status = "Active",
                        JoinDate = DateTime.Now,
                        EmployeeId = GenerateEmployeeId(),
                        Department = "General" // Default department
                    };
                    _context.Employees.Add(employee);
                }

                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "An error occurred while saving employee data." });
            }
        }

        [HttpPost]
        public async Task<IActionResult> SaveProcessChart([FromBody] ProcessChart chart)
        {
            try
            {
                chart.LastUpdated = DateTime.Now;
                chart.CreatedDate = DateTime.Now;
                chart.LastModifiedDate = DateTime.Now;
                chart.Status = "Active";
                _context.ProcessCharts.Add(chart);
                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetProcessChart(int id)
        {
            try
            {
                var chart = await _context.ProcessCharts
                    .FirstOrDefaultAsync(p => p.Id == id);

                if (chart == null)
                {
                    return Json(new { success = false, message = "Chart not found" });
                }

                return Json(new { success = true, data = chart });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteProcessChart(int id, int companyId)
        {
            try
            {
                var chart = await _context.ProcessCharts
                    .FirstOrDefaultAsync(p => p.Id == id && p.CompanyId == companyId);

                if (chart == null)
                {
                    return Json(new { success = false, message = "Chart not found" });
                }

                _context.ProcessCharts.Remove(chart);
                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public async Task<IActionResult> MR(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View(company);
        }

        // DMR Actions
        public async Task<IActionResult> DMR01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR01"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR01.cshtml", company);
        }

        public async Task<IActionResult> DMR02(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR02"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR02.cshtml", company);
        }

        public async Task<IActionResult> DMR03(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR03"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR03.cshtml", company);
        }

        public async Task<IActionResult> DMR04(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR04"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR04.cshtml", company);
        }

        public async Task<IActionResult> DMR05(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR05"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR05.cshtml", company);
        }

        public async Task<IActionResult> DMR06(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR06"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR06.cshtml", company);
        }

        public async Task<IActionResult> DMR07(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR07"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR07.cshtml", company);
        }

        public async Task<IActionResult> DMR08(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR08"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR08.cshtml", company);
        }

        public async Task<IActionResult> DMR09(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR09"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR09.cshtml", company);
        }

        public async Task<IActionResult> DMR10(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR10"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR10.cshtml", company);
        }

        public async Task<IActionResult> DMR11(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR11"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR11.cshtml", company);
        }

        public async Task<IActionResult> DMR12(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR12"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR12.cshtml", company);
        }

        public async Task<IActionResult> DMR13(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "DMR13"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/DMR13.cshtml", company);
        }

        // FMR Actions
        public async Task<IActionResult> FMR01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "FMR01"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/FMR01.cshtml", company);
        }

        public async Task<IActionResult> FMR02(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "FMR02"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/FMR02.cshtml", company);
        }

        public async Task<IActionResult> FMR03(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "FMR03"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/FMR03.cshtml", company);
        }

        public async Task<IActionResult> FMR04(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "FMR04"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/FMR04.cshtml", company);
        }

        public async Task<IActionResult> FMR05(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "FMR05"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/FMR05.cshtml", company);
        }

        public async Task<IActionResult> FMR06(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "FMR06"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/FMR06.cshtml", company);
        }

        public async Task<IActionResult> FMR07(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "FMR07"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/FMR07.cshtml", company);
        }

        public async Task<IActionResult> FMR08(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MRDocuments.Where(d => d.Code == "FMR08"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/FMR08.cshtml", company);
        }

        // PCMR Actions
        public async Task<IActionResult> PCMR01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMR01"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/PCMR01.cshtml", company);
        }

        public async Task<IActionResult> PCMR02(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMR02"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/PCMR02.cshtml", company);
        }

        public async Task<IActionResult> PCMR03(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMR03"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/PCMR03.cshtml", company);
        }

        public async Task<IActionResult> PCMR04(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMR04"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/PCMR04.cshtml", company);
        }

        public async Task<IActionResult> PCMR05(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMR05"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/PCMR05.cshtml", company);
        }

        public async Task<IActionResult> PCMR06(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMR06"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/PCMR06.cshtml", company);
        }

        public async Task<IActionResult> PCMR07(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMR07"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/PCMR07.cshtml", company);
        }

        public async Task<IActionResult> PCMR08(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMR08"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/MR/PCMR08.cshtml", company);
        }

        public async Task<IActionResult> Marketing(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View(company);
        }

        // Marketing Forms
        public async Task<IActionResult> ProductionForm(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/ProductionForm.cshtml", company);
        }

        public async Task<IActionResult> CustomersForm(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/CustomersForm.cshtml", company);
        }

        public async Task<IActionResult> PCMK01(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/PCMK01.cshtml", company);
        }

        public async Task<IActionResult> PCMK02(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/PCMK02.cshtml", company);
        }

        public async Task<IActionResult> FMK01(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/FMK01.cshtml", company);
        }

        public async Task<IActionResult> FMK02(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/FMK02.cshtml", company);
        }

        public async Task<IActionResult> FMK03(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/FMK03.cshtml", company);
        }

        public async Task<IActionResult> FMK04(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/FMK04.cshtml", company);
        }

        public async Task<IActionResult> FMK05(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/FMK05.cshtml", company);
        }

        public async Task<IActionResult> DMK01(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/DMK01.cshtml", company);
        }

        public async Task<IActionResult> DMK02(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Marketing/DMK02.cshtml", company);
        }

        public async Task<IActionResult> Purchase(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View();
        }

        // Purchase Forms
        public async Task<IActionResult> DPR01(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Purchase/DPR01.cshtml", company);
        }

        public async Task<IActionResult> FPR01(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Purchase/FPR01.cshtml", company);
        }

        public async Task<IActionResult> FPR02(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Purchase/FPR02.cshtml", company);
        }

        public async Task<IActionResult> FPR03(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Purchase/FPR03.cshtml", company);
        }

        public async Task<IActionResult> PCPR01(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Purchase/PCPR01.cshtml", company);
        }

        public async Task<IActionResult> PurchaseForm(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/Purchase/Form.cshtml", company);
        }

        // Maintenance Department Actions
        [HttpGet]
        [Route("CompanyDetails/Maintenance/{id}")]
        public async Task<IActionResult> Maintenance(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments)
                .Include(c => c.ProcessCharts.Where(p => p.Title.StartsWith("PCMT")))
                .Include(c => c.Machines)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/Maintenance/Index.cshtml", company);
        }

        [HttpGet]
        [Route("CompanyDetails/Maintenance/Form/{id}")]
        public async Task<IActionResult> MaintenanceForm(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments)
                .Include(c => c.ProcessCharts.Where(p => p.Title.StartsWith("PCMT")))
                .Include(c => c.Machines)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/Maintenance/Form.cshtml", company);
        }

        // Maintenance Document Actions
        [HttpGet]
        [Route("CompanyDetails/Maintenance/DMT01/{id}")]
        public async Task<IActionResult> DMT01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == "DMT01"))
                .Include(c => c.Machines)
                    .ThenInclude(m => m.Company)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/Maintenance/DMT01.cshtml", company);
        }

        [HttpGet]
        [Route("CompanyDetails/Maintenance/DMT02/{id}")]
        public async Task<IActionResult> DMT02(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == "DMT02"))
                .Include(c => c.Machines)
                    .ThenInclude(m => m.Company)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/Maintenance/DMT02.cshtml", company);
        }

        // Maintenance Format Actions
        [HttpGet]
        [Route("CompanyDetails/Maintenance/FMT01/{id}")]
        public async Task<IActionResult> FMT01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == "FMT01"))
                .Include(c => c.Machines)
                    .ThenInclude(m => m.Company)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/Maintenance/FMT01.cshtml", company);
        }

        [HttpGet]
        [Route("CompanyDetails/Maintenance/FMT02/{id}")]
        public async Task<IActionResult> FMT02(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == "FMT02"))
                .Include(c => c.Machines)
                    .ThenInclude(m => m.Company)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/Maintenance/FMT02.cshtml", company);
        }

        // Maintenance Process Chart Actions
        [HttpGet]
        [Route("CompanyDetails/Maintenance/PCMT01/{id}")]
        public async Task<IActionResult> PCMT01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts.Where(p => p.Title == "PCMT01"))
                .Include(c => c.Machines)
                    .ThenInclude(m => m.Company)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View("~/Views/CompanyDetails/Maintenance/PCMT01.cshtml", company);
        }

        // Maintenance1 Actions
        [HttpGet]
        [Route("CompanyDetails/Maintenance1/{id}")]
        public async Task<IActionResult> Maintenance1(int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View(company);
        }

        // Business Management Actions
        [HttpGet]
        [Route("CompanyDetails/BM/{code}/{id}")]
        public async Task<IActionResult> BM(string code, int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == $"BM{code}"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            ViewBag.Code = code;
            return View($"~/Views/CompanyDetails/Maintenance1/BM{code}.cshtml", company);
        }

        // Human Resources Actions
        [HttpGet]
        [Route("CompanyDetails/HP/{code}/{id}")]
        public async Task<IActionResult> HP(string code, int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == $"HP{code}"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View($"~/Views/CompanyDetails/Maintenance1/HP{code}.cshtml", company);
        }

        // Sales & Marketing Actions
        [HttpGet]
        [Route("CompanyDetails/SM/{code}/{id}")]
        public async Task<IActionResult> SM(string code, int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == $"SM{code}"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View($"~/Views/CompanyDetails/Maintenance1/SM{code}.cshtml", company);
        }

        // Production & Logistics Actions
        [HttpGet]
        [Route("CompanyDetails/PL/{code}/{id}")]
        public async Task<IActionResult> PL(string code, int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == $"PL{code}"))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View($"~/Views/CompanyDetails/Maintenance1/PL{code}.cshtml", company);
        }

        // Other Documents Actions
        [HttpGet]
        [Route("CompanyDetails/Document/{code}/{id}")]
        public async Task<IActionResult> OtherDocument(string code, int id)
        {
            var company = await _context.Companies
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == code))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View($"~/Views/CompanyDetails/Maintenance1/{code}.cshtml", company);
        }

        private string GenerateEmployeeId()
        {
            return $"EMP{DateTime.Now:yyyyMMddHHmmss}";
        }
    }
} 