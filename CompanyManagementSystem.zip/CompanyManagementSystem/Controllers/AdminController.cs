using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using CompanyManagementSystem.Data;
using CompanyManagementSystem.Models;
using CompanyManagementSystem.Models.ViewModels;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyManagementSystem.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public AdminController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View("Index");
        }

        // Company Management
        public async Task<IActionResult> Companies()
        {
            var companies = await _context.Companies.ToListAsync();
            return View(companies);
        }

        [HttpGet]
        public IActionResult CreateCompany()
        {
            return View(new CompanyViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateCompany(CompanyViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if email already exists
                var existingUser = await _userManager.FindByEmailAsync(model.CompanyPersonEmail);
                if (existingUser != null)
                {
                    ModelState.AddModelError("CompanyPersonEmail", "This email is already registered.");
                    return View(model);
                }

                // Handle file uploads
                string signature1Path = null;
                string signature2Path = null;

                if (model.Signature1 != null && model.Signature1.Length > 0)
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "signatures");
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Signature1.FileName;
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await model.Signature1.CopyToAsync(stream);
                    }
                    signature1Path = Path.Combine("uploads", "signatures", uniqueFileName);
                }

                if (model.Signature2 != null && model.Signature2.Length > 0)
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "signatures");
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Signature2.FileName;
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await model.Signature2.CopyToAsync(stream);
                    }
                    signature2Path = Path.Combine("uploads", "signatures", uniqueFileName);
                }

                // Create the company
                var company = new Company
                {
                    CompanyName = model.CompanyName,
                    Name = model.CompanyName,
                    Address = model.Address,
                    Scope = model.Scope,
                    RevisionNo = model.RevisionNo,
                    RevisionDate = model.RevisionDate,
                    CompanyPersonName = model.CompanyPersonName,
                    CompanyPersonEmail = model.CompanyPersonEmail,
                    CompanyPersonPassword = model.CompanyPersonPassword,
                    CompanyType = model.CompanyType,
                    ShortName = model.ShortName,
                    Website = "",
                    CreatedDate = DateTime.Now,
                    LastModifiedDate = null,
                    Signature1Path = signature1Path,
                    Signature2Path = signature2Path
                };

                _context.Companies.Add(company);
                await _context.SaveChangesAsync();

                // Create user account for company person
                var user = new ApplicationUser
                {
                    UserName = model.CompanyPersonEmail,
                    Email = model.CompanyPersonEmail,
                    CompanyId = company.Id,
                    FirstName = model.CompanyPersonName.Split(' ')[0],
                    LastName = model.CompanyPersonName.Split(' ').Length > 1 ? string.Join(" ", model.CompanyPersonName.Split(' ').Skip(1)) : ""
                };

                var result = await _userManager.CreateAsync(user, model.CompanyPersonPassword);
                if (result.Succeeded)
                {
                    await _userManager.AddToRoleAsync(user, "User");
                    TempData["SuccessMessage"] = "Company and user account created successfully.";
                    return RedirectToAction(nameof(Companies));
                }
                else
                {
                    // If user creation fails, remove the company
                    _context.Companies.Remove(company);
                    await _context.SaveChangesAsync();
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }
                }
            }
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> EditCompany(int id)
        {
            var company = await _context.Companies.FindAsync(id);
            if (company == null)
            {
                return NotFound();
            }

            var model = new CompanyViewModel
            {
                Id = company.Id,
                CompanyName = company.CompanyName,
                Address = company.Address,
                Scope = company.Scope,
                RevisionNo = company.RevisionNo,
                RevisionDate = company.RevisionDate,
                CompanyPersonName = company.CompanyPersonName,
                CompanyPersonEmail = company.CompanyPersonEmail,
                CompanyType = company.CompanyType,
                ShortName = company.ShortName
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditCompany(int id, CompanyViewModel model)
        {
            if (ModelState.IsValid)
            {
                var company = await _context.Companies.FindAsync(id);
                if (company == null)
                {
                    return NotFound();
                }

                // Check if email is being changed and if it already exists
                if (company.CompanyPersonEmail != model.CompanyPersonEmail)
                {
                    var existingUser = await _userManager.FindByEmailAsync(model.CompanyPersonEmail);
                    if (existingUser != null)
                    {
                        ModelState.AddModelError("CompanyPersonEmail", "This email is already registered.");
                        return View(model);
                    }
                }

                // Handle file uploads
                if (model.Signature1 != null && model.Signature1.Length > 0)
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "signatures");
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Signature1.FileName;
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await model.Signature1.CopyToAsync(stream);
                    }
                    company.Signature1Path = Path.Combine("uploads", "signatures", uniqueFileName);
                }

                if (model.Signature2 != null && model.Signature2.Length > 0)
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "signatures");
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Signature2.FileName;
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await model.Signature2.CopyToAsync(stream);
                    }
                    company.Signature2Path = Path.Combine("uploads", "signatures", uniqueFileName);
                }

                // Update company details
                company.CompanyName = model.CompanyName;
                company.Name = model.CompanyName;
                company.Address = model.Address;
                company.Scope = model.Scope;
                company.RevisionNo = model.RevisionNo;
                company.RevisionDate = model.RevisionDate;
                company.CompanyPersonName = model.CompanyPersonName;
                company.CompanyPersonEmail = model.CompanyPersonEmail;
                company.CompanyType = model.CompanyType;
                company.ShortName = model.ShortName;
                company.LastModifiedDate = DateTime.Now;

                // Update user account if email or password changed
                var user = await _userManager.FindByEmailAsync(company.CompanyPersonEmail);
                if (user != null)
                {
                    if (company.CompanyPersonEmail != model.CompanyPersonEmail)
                    {
                        user.Email = model.CompanyPersonEmail;
                        user.UserName = model.CompanyPersonEmail;
                    }

                    if (!string.IsNullOrEmpty(model.CompanyPersonPassword))
                    {
                        var token = await _userManager.GeneratePasswordResetTokenAsync(user);
                        await _userManager.ResetPasswordAsync(user, token, model.CompanyPersonPassword);
                    }

                    await _userManager.UpdateAsync(user);
                }

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Company and user account updated successfully.";
                return RedirectToAction(nameof(Companies));
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCompany(int id)
        {
            try
            {
                var company = await _context.Companies
                    .Include(c => c.Employees)
                    .Include(c => c.HRDocuments)
                    .Include(c => c.Issues)
                    .Include(c => c.Machines)
                    .Include(c => c.MaintenanceDocuments)
                    .Include(c => c.MarketingDocuments)
                    .Include(c => c.MRDocuments)
                    .Include(c => c.OrganizationCharts)
                    .Include(c => c.PDFFiles)
                    .Include(c => c.ProcessCharts)
                    .Include(c => c.PurchaseDocuments)
                    .Include(c => c.QCDocuments)
                    .Include(c => c.StoreDocuments)
                    .FirstOrDefaultAsync(c => c.Id == id);

                if (company == null)
                {
                    TempData["ErrorMessage"] = "Company not found.";
                    return RedirectToAction(nameof(Companies));
                }

                // Delete associated user account
                var user = await _userManager.FindByEmailAsync(company.CompanyPersonEmail);
                if (user != null)
                {
                    await _userManager.DeleteAsync(user);
                }

                // Delete signature files if they exist
                if (!string.IsNullOrEmpty(company.Signature1Path))
                {
                    var signature1Path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", company.Signature1Path);
                    if (System.IO.File.Exists(signature1Path))
                    {
                        System.IO.File.Delete(signature1Path);
                    }
                }

                if (!string.IsNullOrEmpty(company.Signature2Path))
                {
                    var signature2Path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", company.Signature2Path);
                    if (System.IO.File.Exists(signature2Path))
                    {
                        System.IO.File.Delete(signature2Path);
                    }
                }

                // Delete all related data
                _context.Employees.RemoveRange(company.Employees);
                _context.HRDocuments.RemoveRange(company.HRDocuments);
                _context.Issues.RemoveRange(company.Issues);
                _context.Machines.RemoveRange(company.Machines);
                _context.MaintenanceDocuments.RemoveRange(company.MaintenanceDocuments);
                _context.MarketingDocuments.RemoveRange(company.MarketingDocuments);
                _context.MRDocuments.RemoveRange(company.MRDocuments);
                _context.OrganizationCharts.RemoveRange(company.OrganizationCharts);
                _context.PDFFiles.RemoveRange(company.PDFFiles);
                _context.ProcessCharts.RemoveRange(company.ProcessCharts);
                _context.PurchaseDocuments.RemoveRange(company.PurchaseDocuments);
                _context.QCDocuments.RemoveRange(company.QCDocuments);
                _context.StoreDocuments.RemoveRange(company.StoreDocuments);

                // Delete the company
                _context.Companies.Remove(company);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Company and all related data deleted successfully.";
                return RedirectToAction(nameof(Companies));
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "An error occurred while deleting the company. Please try again.";
                return RedirectToAction(nameof(Companies));
            }
        }

        // PDF File Management
        public async Task<IActionResult> PDFFiles()
        {
            var files = await _context.PDFFiles
                .Include(f => f.Company)
                .ToListAsync();
            return View(files);
        }

        [HttpGet]
        public IActionResult UploadPDF()
        {
            ViewBag.Companies = _context.Companies.ToList();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadPDF(PDFFile file, IFormFile pdfFile)
        {
            if (ModelState.IsValid && pdfFile != null)
            {
                // Save file to server
                var fileName = Path.GetFileName(pdfFile.FileName);
                var filePath = Path.Combine("wwwroot", "pdfs", fileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await pdfFile.CopyToAsync(stream);
                }

                file.FilePath = filePath;
                file.FileName = fileName;
                file.UpdatedBy = User.Identity?.Name ?? "Unknown";

                _context.Add(file);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(PDFFiles));
            }

            ViewBag.Companies = _context.Companies.ToList();
            return View(file);
        }

        // User Management
        public async Task<IActionResult> Users()
        {
            var users = await _userManager.Users.ToListAsync();
            return View(users);
        }

        // Reports
        public IActionResult Reports()
        {
            return View();
        }

        // Settings
        public IActionResult Settings()
        {
            return View();
        }

        // Department Management
        public IActionResult HR()
        {
            return View();
        }

        public IActionResult MR()
        {
            return View();
        }

        public IActionResult Marketing()
        {
            return View();
        }

        public IActionResult Purchase()
        {
            return View();
        }

        public IActionResult Maintenance()
        {
            return View();
        }

        public IActionResult Maintenance1()
        {
            return View();
        }

        public IActionResult Store()
        {
            return View();
        }

        public IActionResult QC()
        {
            return View();
        }
    }
} 