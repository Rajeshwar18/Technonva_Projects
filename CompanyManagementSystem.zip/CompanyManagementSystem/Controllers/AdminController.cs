using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompanyManagementSystem.Data;
using CompanyManagementSystem.Models;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyManagementSystem.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public AdminController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View("Index");
        }

        // Company Management
        public async Task<IActionResult> Companies()
        {
            var companies = await _context.Companies.ToListAsync();
            return View(companies);
        }

        [HttpGet]
        public IActionResult CreateCompany()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateCompany(CompanyViewModel model)
        {
            if (ModelState.IsValid)
            {
                var company = new Company
                {
                    CompanyName = model.CompanyName,
                    Address = model.Address,
                    Scope = model.Scope,
                    RevisionNo = model.RevisionNo,
                    RevisionDate = model.RevisionDate,
                    CompanyPersonName = model.CompanyPersonName,
                    CompanyType = model.CompanyType,
                    ShortName = model.ShortName,
                    SignatureBlock = model.SignatureBlock
                };

                _context.Companies.Add(company);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Company created successfully.";
                return RedirectToAction(nameof(Companies));
            }

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> EditCompany(int id)
        {
            var company = await _context.Companies.FindAsync(id);
            if (company == null)
            {
                return NotFound();
            }

            var model = new CompanyViewModel
            {
                CompanyName = company.CompanyName,
                Address = company.Address,
                Scope = company.Scope,
                RevisionNo = company.RevisionNo,
                RevisionDate = company.RevisionDate,
                CompanyPersonName = company.CompanyPersonName,
                CompanyType = company.CompanyType,
                ShortName = company.ShortName,
                SignatureBlock = company.SignatureBlock
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditCompany(int id, CompanyViewModel model)
        {
            if (ModelState.IsValid)
            {
                var company = await _context.Companies.FindAsync(id);
                if (company == null)
                {
                    return NotFound();
                }

                company.CompanyName = model.CompanyName;
                company.Address = model.Address;
                company.Scope = model.Scope;
                company.RevisionNo = model.RevisionNo;
                company.RevisionDate = model.RevisionDate;
                company.CompanyPersonName = model.CompanyPersonName;
                company.CompanyType = model.CompanyType;
                company.ShortName = model.ShortName;
                company.SignatureBlock = model.SignatureBlock;

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Company updated successfully.";
                return RedirectToAction(nameof(Companies));
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCompany(int id)
        {
            var company = await _context.Companies.FindAsync(id);
            if (company == null)
            {
                return NotFound();
            }

            _context.Companies.Remove(company);
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Company deleted successfully.";
            return RedirectToAction(nameof(Companies));
        }

        // PDF File Management
        public async Task<IActionResult> PDFFiles()
        {
            var files = await _context.PDFFiles
                .Include(f => f.Company)
                .ToListAsync();
            return View(files);
        }

        [HttpGet]
        public IActionResult UploadPDF()
        {
            ViewBag.Companies = _context.Companies.ToList();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadPDF(PDFFile file, IFormFile pdfFile)
        {
            if (ModelState.IsValid && pdfFile != null)
            {
                // Save file to server
                var fileName = Path.GetFileName(pdfFile.FileName);
                var filePath = Path.Combine("wwwroot", "pdfs", fileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await pdfFile.CopyToAsync(stream);
                }

                file.FilePath = filePath;
                file.FileName = fileName;
                file.UpdatedBy = User.Identity?.Name ?? "Unknown";

                _context.Add(file);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(PDFFiles));
            }

            ViewBag.Companies = _context.Companies.ToList();
            return View(file);
        }

        // User Management
        public async Task<IActionResult> Users()
        {
            var users = await _userManager.Users.ToListAsync();
            return View(users);
        }

        // Reports
        public IActionResult Reports()
        {
            return View();
        }

        // Settings
        public IActionResult Settings()
        {
            return View();
        }

        // Department Management
        public IActionResult HR()
        {
            return View();
        }

        public IActionResult MR()
        {
            return View();
        }

        public IActionResult Marketing()
        {
            return View();
        }

        public IActionResult Purchase()
        {
            return View();
        }

        public IActionResult Maintenance()
        {
            return View();
        }

        public IActionResult Maintenance1()
        {
            return View();
        }

        public IActionResult Store()
        {
            return View();
        }

        public IActionResult QC()
        {
            return View();
        }
    }
} 