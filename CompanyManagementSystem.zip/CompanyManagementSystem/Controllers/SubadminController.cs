using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompanyManagementSystem.Data;
using CompanyManagementSystem.Models;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyManagementSystem.Controllers
{
    [Authorize(Roles = "Subadmin")]
    public class SubadminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SubadminController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        // Department Actions
        public IActionResult HR()
        {
            return View();
        }

        public IActionResult MR()
        {
            return View();
        }

        public IActionResult Marketing()
        {
            return View();
        }

        public IActionResult Purchase()
        {
            return View();
        }

        public IActionResult Maintenance()
        {
            return View();
        }

        public IActionResult Maintenance1()
        {
            return View();
        }

        public IActionResult Store()
        {
            return View();
        }

        public IActionResult QC()
        {
            return View();
        }

        // PDF File Management (Edit only)
        public async Task<IActionResult> PDFFiles()
        {
            var files = await _context.PDFFiles
                .Include(f => f.Company)
                .ToListAsync();
            return View(files);
        }

        [HttpGet]
        public async Task<IActionResult> EditPDF(int id)
        {
            var file = await _context.PDFFiles
                .Include(f => f.Company)
                .FirstOrDefaultAsync(f => f.Id == id);

            if (file == null)
            {
                return NotFound();
            }

            ViewBag.Companies = await _context.Companies.ToListAsync();
            return View(file);
        }

        [HttpPost]
        public async Task<IActionResult> EditPDF(int id, PDFFile file)
        {
            if (id != file.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    file.UpdatedAt = DateTime.Now;
                    file.UpdatedBy = User.Identity.Name;
                    _context.Update(file);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PDFFileExists(file.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(PDFFiles));
            }

            ViewBag.Companies = await _context.Companies.ToListAsync();
            return View(file);
        }

        private bool PDFFileExists(int id)
        {
            return _context.PDFFiles.Any(e => e.Id == id);
        }
    }
} 