using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompanyManagementSystem.Data;
using CompanyManagementSystem.Models;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Identity;

namespace CompanyManagementSystem.Controllers
{
    [Authorize]
    public class HRController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public HRController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: HR/Employees/{companyId}
        public async Task<IActionResult> Employees(int id)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                var company = await _context.Companies
                    .Include(c => c.Employees)
                    .AsNoTracking()
                    .FirstOrDefaultAsync(c => c.Id == id);

                if (company == null)
                {
                    return NotFound();
                }

                // Check if user is admin or owns the company
                if (!User.IsInRole("Admin") && user?.CompanyId != id)
                {
                    return Unauthorized();
                }

                // Ensure employees are ordered by Sr number
                company.Employees = company.Employees?.OrderBy(e => e.Sr).ToList();

                ViewBag.CompanyId = id;
                ViewBag.CompanyName = company.Name;
                return View("~/Views/CompanyDetails/HR/FHR01.cshtml", company);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error loading employee data: " + ex.Message });
            }
        }

        // GET: HR/Form/{companyId}
        public async Task<IActionResult> Form(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            var company = await _context.Companies.FindAsync(id);
            
            if (company == null)
            {
                return NotFound();
            }

            // Check if user is admin or owns the company
            if (!User.IsInRole("Admin") && user?.CompanyId != id)
            {
                return Unauthorized();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View("~/Views/CompanyDetails/HR/Form.cshtml", company);
        }

        // POST: HR/SaveEmployeeData
        [HttpPost]
        public async Task<IActionResult> SaveEmployeeData([FromBody] EmployeeDataViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { success = false, message = "Invalid data provided." });
                }

                var user = await _userManager.GetUserAsync(User);
                var company = await _context.Companies
                    .Include(c => c.Employees)
                    .FirstOrDefaultAsync(c => c.Id == model.CompanyId);

                if (company == null)
                {
                    return Json(new { success = false, message = "Company not found." });
                }

                // Check if user is admin or owns the company
                if (!User.IsInRole("Admin") && user?.CompanyId != model.CompanyId)
                {
                    return Json(new { success = false, message = "Unauthorized access." });
                }

                // Remove existing employees for this company
                var existingEmployees = await _context.Employees
                    .Where(e => e.CompanyId == model.CompanyId)
                    .ToListAsync();
                _context.Employees.RemoveRange(existingEmployees);

                // Add new employees
                foreach (var employeeData in model.Employees)
                {
                    if (string.IsNullOrEmpty(employeeData.Name) || 
                        string.IsNullOrEmpty(employeeData.Designation) || 
                        string.IsNullOrEmpty(employeeData.Department) || 
                        string.IsNullOrEmpty(employeeData.Qualification))
                    {
                        return Json(new { success = false, message = "All fields are required for each employee." });
                    }

                    var employee = new Employee
                    {
                        CompanyId = model.CompanyId,
                        Sr = employeeData.Sr,
                        Name = employeeData.Name,
                        Designation = employeeData.Designation,
                        Department = employeeData.Department,
                        Qualification = employeeData.Qualification,
                        JoinDate = DateTime.Parse(employeeData.JoinDate),
                        JoiningYear = employeeData.JoiningYear,
                        Experience = employeeData.Experience,
                        Status = employeeData.Status,
                        EmployeeId = GenerateEmployeeId()
                    };
                    _context.Employees.Add(employee);
                }

                await _context.SaveChangesAsync();

                // Refresh the company data
                company = await _context.Companies
                    .Include(c => c.Employees)
                    .AsNoTracking()
                    .FirstOrDefaultAsync(c => c.Id == model.CompanyId);

                return Json(new { success = true, message = "Employee data saved successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "An error occurred while saving employee data: " + ex.Message });
            }
        }

        // POST: HR/DeleteEmployee/{id}
        [HttpPost]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                var employee = await _context.Employees
                    .Include(e => e.Company)
                    .FirstOrDefaultAsync(e => e.Id == id);

                if (employee == null)
                {
                    return Json(new { success = false, message = "Employee not found" });
                }

                // Check if user is admin or owns the company
                if (!User.IsInRole("Admin") && user?.CompanyId != employee.Company.Id)
                {
                    return Json(new { success = false, message = "Unauthorized access." });
                }

                _context.Employees.Remove(employee);
                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // GET: HR/EditEmployee/{id}
        public async Task<IActionResult> EditEmployee(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            var employee = await _context.Employees
                .Include(e => e.Company)
                .FirstOrDefaultAsync(e => e.Id == id);

            if (employee == null)
            {
                return NotFound();
            }

            // Check if user is admin or owns the company
            if (!User.IsInRole("Admin") && user?.CompanyId != employee.Company.Id)
            {
                return Unauthorized();
            }

            ViewBag.CompanyId = employee.CompanyId;
            ViewBag.CompanyName = employee.Company.Name;
            return View("~/Views/CompanyDetails/HR/EditEmployee.cshtml", employee);
        }

        // POST: HR/UpdateEmployee
        [HttpPost]
        public async Task<IActionResult> UpdateEmployee(Employee employee)
        {
            try
            {
                var existingEmployee = await _context.Employees.FindAsync(employee.Id);
                if (existingEmployee == null)
                {
                    return Json(new { success = false, message = "Employee not found" });
                }

                existingEmployee.Name = employee.Name;
                existingEmployee.Designation = employee.Designation;
                existingEmployee.Qualification = employee.Qualification;
                existingEmployee.JoiningYear = employee.JoiningYear;
                existingEmployee.Experience = employee.Experience;
                existingEmployee.Status = employee.Status;

                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateDHR01([FromBody] UpdateDHR01Request request)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                var company = await _context.Companies
                    .Include(c => c.Employees)
                    .FirstOrDefaultAsync(c => c.Id == request.CompanyId);

                if (company == null)
                {
                    return Json(new { success = false, message = "Company not found." });
                }

                // Check if user is admin or owns the company
                if (!User.IsInRole("Admin") && user?.CompanyId != request.CompanyId)
                {
                    return Json(new { success = false, message = "Unauthorized access." });
                }

                // Calculate statistics from employee data
                var employeeStats = new
                {
                    TotalEmployees = company.Employees.Count,
                    ActiveEmployees = company.Employees.Count(e => e.Status == "Active"),
                    InactiveEmployees = company.Employees.Count(e => e.Status == "Inactive"),
                    OnLeaveEmployees = company.Employees.Count(e => e.Status == "On Leave"),
                    GeneralDepartment = company.Employees.Count(e => e.Department == "General"),
                    HRDepartment = company.Employees.Count(e => e.Department == "HR"),
                    FinanceDepartment = company.Employees.Count(e => e.Department == "Finance"),
                    ITDepartment = company.Employees.Count(e => e.Department == "IT"),
                    OperationsDepartment = company.Employees.Count(e => e.Department == "Operations"),
                    SalesDepartment = company.Employees.Count(e => e.Department == "Sales"),
                    MarketingDepartment = company.Employees.Count(e => e.Department == "Marketing")
                };

                return Json(new { success = true, data = employeeStats });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public class UpdateDHR01Request
        {
            public int CompanyId { get; set; }
        }

        private string GenerateEmployeeId()
        {
            // Generate a unique employee ID using timestamp
            return $"EMP{DateTime.Now:yyyyMMddHHmmss}";
        }

        // GET: HR/DHR01/{companyId}
        public async Task<IActionResult> DHR01(int id)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                var company = await _context.Companies
                    .Include(c => c.Employees)
                    .AsNoTracking()
                    .FirstOrDefaultAsync(c => c.Id == id);

                if (company == null)
                {
                    return NotFound();
                }

                // Check if user is admin or owns the company
                if (!User.IsInRole("Admin") && user?.CompanyId != id)
                {
                    return Unauthorized();
                }

                ViewBag.CompanyId = id;
                ViewBag.CompanyName = company.Name;
                return View("~/Views/CompanyDetails/HR/DHR01.cshtml", company);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error loading DHR01 data: " + ex.Message });
            }
        }

        // GET: HR/FHR01/{companyId}
        public async Task<IActionResult> FHR01(int id)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                var company = await _context.Companies
                    .Include(c => c.Employees)
                    .AsNoTracking()
                    .FirstOrDefaultAsync(c => c.Id == id);

                if (company == null)
                {
                    return NotFound();
                }

                // Check if user is admin or owns the company
                if (!User.IsInRole("Admin") && user?.CompanyId != id)
                {
                    return Unauthorized();
                }

                ViewBag.CompanyId = id;
                ViewBag.CompanyName = company.Name;
                return View("~/Views/CompanyDetails/HR/FHR01.cshtml", company);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error loading FHR01 data: " + ex.Message });
            }
        }
    }
} 