using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompanyManagementSystem.Data;
using CompanyManagementSystem.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using CompanyManagementSystem.Models.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CompanyManagementSystem.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ApplicationDbContext _context;

        public UserController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            ApplicationDbContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _context = context;
        }

        [AllowAnonymous]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser
                {
                    UserName = model.Email,
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName
                };

                var result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    await _userManager.AddToRoleAsync(user, "User");
                    await _signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("Index", "User");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }

            return View(model);
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> HR()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            if (user.CompanyId == null)
            {
                return View("NoCompany");
            }

            // Get company with employees
            var company = await _context.Companies
                .Include(c => c.Employees)
                .FirstOrDefaultAsync(c => c.Id == user.CompanyId);

            if (company == null)
            {
                return NotFound();
            }

            // Pass the company ID to the view
            ViewBag.CompanyId = user.CompanyId;
            ViewBag.CompanyName = company.Name;
            
            return View(company);
        }

        public async Task<IActionResult> HRForm()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            if (user.CompanyId == null)
            {
                return View("NoCompany");
            }

            // Get company with employees
            var company = await _context.Companies
                .Include(c => c.Employees)
                .FirstOrDefaultAsync(c => c.Id == user.CompanyId);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = user.CompanyId;
            ViewBag.CompanyName = company.Name;
            
            return View(company);
        }

        [HttpPost]
        public async Task<IActionResult> SaveEmployeeData([FromBody] Models.EmployeeDataViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { success = false, message = "Invalid data provided." });
                }

                var user = await _userManager.GetUserAsync(User);
                var company = await _context.Companies
                    .Include(c => c.Employees)
                    .FirstOrDefaultAsync(c => c.Id == model.CompanyId);

                if (company == null)
                {
                    return Json(new { success = false, message = "Company not found." });
                }

                // Check if user owns the company
                if (user?.CompanyId != model.CompanyId)
                {
                    return Json(new { success = false, message = "Unauthorized access." });
                }

                // Remove existing employees for this company
                var existingEmployees = await _context.Employees
                    .Where(e => e.CompanyId == model.CompanyId)
                    .ToListAsync();
                _context.Employees.RemoveRange(existingEmployees);

                // Add new employees
                foreach (var employeeData in model.Employees)
                {
                    if (string.IsNullOrEmpty(employeeData.Name) || 
                        string.IsNullOrEmpty(employeeData.Designation) || 
                        string.IsNullOrEmpty(employeeData.Department) || 
                        string.IsNullOrEmpty(employeeData.Qualification))
                    {
                        return Json(new { success = false, message = "All fields are required for each employee." });
                    }

                    // Parse the date from dd/MM/yyyy format
                    DateTime joinDate;
                    if (!DateTime.TryParseExact(employeeData.JoinDate, "dd/MM/yyyy", 
                        System.Globalization.CultureInfo.InvariantCulture, 
                        System.Globalization.DateTimeStyles.None, out joinDate))
                    {
                        return Json(new { success = false, message = "Invalid date format. Please use dd/MM/yyyy." });
                    }

                    var employee = new Employee
                    {
                        CompanyId = model.CompanyId,
                        Sr = employeeData.Sr,
                        Name = employeeData.Name,
                        Designation = employeeData.Designation,
                        Department = employeeData.Department,
                        Qualification = employeeData.Qualification,
                        JoinDate = joinDate,
                        Status = employeeData.Status
                    };

                    _context.Employees.Add(employee);
                }

                await _context.SaveChangesAsync();
                return Json(new { success = true, message = "Employee data saved successfully." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "An error occurred while saving employee data: " + ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateEmployee([FromBody] Employee employee)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null || user.CompanyId != employee.CompanyId)
                {
                    return Json(new { success = false, message = "Unauthorized access." });
                }

                if (employee.Id > 0)
                {
                    // Update existing employee
                    var existingEmployee = await _context.Employees.FindAsync(employee.Id);
                    if (existingEmployee == null)
                    {
                        return Json(new { success = false, message = "Employee not found." });
                    }

                    existingEmployee.Sr = employee.Sr;
                    existingEmployee.Name = employee.Name;
                    existingEmployee.Designation = employee.Designation;
                    existingEmployee.Department = employee.Department;
                    existingEmployee.Qualification = employee.Qualification;
                    existingEmployee.JoinDate = employee.JoinDate;
                    existingEmployee.JoiningYear = employee.JoiningYear;
                    existingEmployee.Experience = employee.Experience;
                    existingEmployee.Status = employee.Status;
                }
                else
                {
                    // Add new employee
                    employee.EmployeeId = GenerateEmployeeId();
                    _context.Employees.Add(employee);
                }

                await _context.SaveChangesAsync();
                return Json(new { success = true, message = "Employee saved successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "An error occurred while saving employee: " + ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null || !user.CompanyId.HasValue)
                {
                    return Json(new { success = false, message = "User not authorized" });
                }

                var employee = await _context.Employees.FindAsync(id);
                if (employee == null || employee.CompanyId != user.CompanyId.Value)
                {
                    return Json(new { success = false, message = "Employee not found or not authorized" });
                }

                _context.Employees.Remove(employee);
                await _context.SaveChangesAsync();

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        private string GenerateEmployeeId()
        {
            return "EMP" + DateTime.Now.ToString("yyyyMMddHHmmss");
        }

        public IActionResult Marketing()
        {
            return View();
        }

        public IActionResult Purchase()
        {
            return View();
        }

        public async Task<IActionResult> Maintenance()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            if (user.CompanyId == null)
            {
                return View("NoCompany");
            }

            // Get company with machines and maintenance documents
            var company = await _context.Companies
                .Include(c => c.Machines)
                .Include(c => c.MaintenanceDocuments.Where(d => d.Code == "FMT01"))
                .FirstOrDefaultAsync(c => c.Id == user.CompanyId);

            if (company == null)
            {
                return NotFound();
            }

            return View(company);
        }

        [HttpPost]
        public async Task<IActionResult> SaveMaintenanceRecord([FromBody] MaintenanceDocument document)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    return Json(new { success = false, message = "User not found" });
                }

                if (user.CompanyId == null)
                {
                    return Json(new { success = false, message = "User is not associated with any company" });
                }

                // Get the machine details
                var machine = await _context.Machines.FindAsync(document.MachineId);
                if (machine == null)
                {
                    return Json(new { success = false, message = "Machine not found" });
                }

                // Create new maintenance document
                var maintenanceDoc = new MaintenanceDocument
                {
                    CompanyId = user.CompanyId.Value,
                    Code = "FMT01",
                    Title = machine.MachineName,
                    Content = document.Content,
                    WorkDone = document.WorkDone,
                    PartsReplaced = document.PartsReplaced,
                    MaintenanceBy = document.MaintenanceBy,
                    MaintenanceDate = document.MaintenanceDate,
                    TotalHours = document.TotalHours,
                    SupervisorSign = document.SupervisorSign,
                    Status = document.Status,
                    Date = document.Date,
                    Time = document.Time
                };

                _context.MaintenanceDocuments.Add(maintenanceDoc);
                await _context.SaveChangesAsync();

                return Json(new { success = true, message = "Maintenance record saved successfully" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Error saving maintenance record: {ex.Message}" });
            }
        }

        public IActionResult QC()
        {
            return View();
        }

        public IActionResult Reports()
        {
            return View();
        }
        

        public async Task<IActionResult> Profile()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            var model = new ProfileViewModel
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateProfile(ProfileViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    return NotFound();
                }

                user.FirstName = model.FirstName;
                user.LastName = model.LastName;
                user.Email = model.Email;

                var result = await _userManager.UpdateAsync(user);
                if (result.Succeeded)
                {
                    TempData["SuccessMessage"] = "Profile updated successfully!";
                    return RedirectToAction("Profile");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }

            return View("Profile", model);
        }
    }
} 