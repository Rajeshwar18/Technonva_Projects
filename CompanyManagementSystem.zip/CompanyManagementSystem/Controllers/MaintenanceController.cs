using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompanyManagementSystem.Models;
using CompanyManagementSystem.Data;

namespace CompanyManagementSystem.Controllers
{
    public class MaintenanceController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MaintenanceController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Maintenance
        public IActionResult Index()
        {
            return View();
        }

        // GET: Maintenance/GetMachine/{id}
        [HttpGet]
        public async Task<IActionResult> GetMachine(int id)
        {
            var machine = await _context.Machines.FindAsync(id);
            if (machine == null)
            {
                return Json(new { success = false, message = "Machine not found" });
            }
            return Json(machine);
        }

        // GET: Maintenance/Form/{companyId}
        public async Task<IActionResult> Form(int id)
        {
            var company = await _context.Companies
                .Include(c => c.Machines)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            return View("~/Views/CompanyDetails/Maintenance/Form.cshtml", company);
        }

        // POST: Maintenance/SaveMachines
        [HttpPost]
        public async Task<IActionResult> SaveMachines([FromBody] SaveMachinesRequest request)
        {
            try
            {
                if (request == null)
                {
                    return Json(new { success = false, message = "Request data is null" });
                }

                if (request.Machines == null || !request.Machines.Any())
                {
                    return Json(new { success = false, message = "No machines data provided" });
                }

                if (request.CompanyId <= 0)
                {
                    return Json(new { success = false, message = "Invalid company ID" });
                }

                // Get existing machines for this company
                var existingMachines = await _context.Machines
                    .Where(m => m.CompanyId == request.CompanyId)
                    .ToListAsync();

                // Remove machines that are no longer in the request
                var machinesToDelete = existingMachines
                    .Where(em => !request.Machines.Any(m => m.Id == em.Id))
                    .ToList();

                foreach (var machine in machinesToDelete)
                {
                    _context.Machines.Remove(machine);
                }

                // Update or add machines
                foreach (var machine in request.Machines)
                {
                    if (machine == null)
                    {
                        continue; // Skip null machines
                    }

                    machine.CompanyId = request.CompanyId;

                    if (machine.Id == 0)
                    {
                        // New machine
                        machine.CreatedDate = DateTime.Now;
                        _context.Machines.Add(machine);
                    }
                    else
                    {
                        // Update existing machine
                        var existingMachine = await _context.Machines.FindAsync(machine.Id);
                        if (existingMachine != null)
                        {
                            existingMachine.Sr = machine.Sr;
                            existingMachine.Code = machine.Code ?? string.Empty;
                            existingMachine.MachineName = machine.MachineName ?? string.Empty;
                            existingMachine.Make = machine.Make ?? string.Empty;
                            existingMachine.Capacity = machine.Capacity ?? string.Empty;
                            existingMachine.Department = machine.Department ?? string.Empty;
                            existingMachine.Parameters = machine.Parameters;
                            existingMachine.DailySchedule = machine.DailySchedule;
                            existingMachine.WeeklySchedule = machine.WeeklySchedule;
                            existingMachine.MonthlySchedule = machine.MonthlySchedule;
                            existingMachine.LastModifiedDate = DateTime.Now;
                        }
                    }
                }

                await _context.SaveChangesAsync();

                return Json(new { success = true, message = "Machines saved successfully" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Error saving machines: {ex.Message}" });
            }
        }

        // POST: Maintenance/DeleteMachine
        [HttpPost]
        public async Task<IActionResult> DeleteMachine(int id)
        {
            try
            {
                var machine = await _context.Machines.FindAsync(id);
                if (machine == null)
                {
                    return Json(new { success = false, message = "Machine not found" });
                }

                _context.Machines.Remove(machine);
                await _context.SaveChangesAsync();

                return Json(new { success = true, message = "Machine deleted successfully" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // GET: Maintenance/GetMachines/{companyId}
        [HttpGet]
        public async Task<IActionResult> GetMachines(int companyId)
        {
            var machines = await _context.Machines
                .Where(m => m.CompanyId == companyId)
                .OrderBy(m => m.Sr)
                .ToListAsync();

            return Json(machines);
        }

        // GET: Maintenance/GetMaintenanceDocuments/{companyId}/{code}
        [HttpGet]
        public async Task<IActionResult> GetMaintenanceDocuments(int companyId, string code)
        {
            var documents = await _context.MaintenanceDocuments
                .Where(d => d.CompanyId == companyId && d.Code == code)
                .OrderBy(d => d.Date)
                .ToListAsync();

            return Json(documents);
        }

        // POST: Maintenance/SaveMaintenanceDocument
        [HttpPost]
        public async Task<IActionResult> SaveMaintenanceDocument([FromBody] MaintenanceDocument document)
        {
            try
            {
                if (document == null)
                {
                    return Json(new { success = false, message = "Document data is null" });
                }

                if (document.CompanyId <= 0)
                {
                    return Json(new { success = false, message = "Invalid company ID" });
                }

                if (string.IsNullOrEmpty(document.Code))
                {
                    return Json(new { success = false, message = "Document code is required" });
                }

                if (document.Id == 0)
                {
                    // New document
                    document.Date = DateTime.Now;
                    _context.MaintenanceDocuments.Add(document);
                }
                else
                {
                    // Update existing document
                    var existingDoc = await _context.MaintenanceDocuments.FindAsync(document.Id);
                    if (existingDoc != null)
                    {
                        existingDoc.Title = document.Title;
                        existingDoc.Content = document.Content;
                        existingDoc.Status = document.Status;
                        existingDoc.Version = document.Version;
                    }
                }

                await _context.SaveChangesAsync();
                return Json(new { success = true, message = "Document saved successfully" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Error saving document: {ex.Message}" });
            }
        }

        // POST: Maintenance/DeleteMaintenanceDocument
        [HttpPost]
        public async Task<IActionResult> DeleteMaintenanceDocument(int id)
        {
            try
            {
                var document = await _context.MaintenanceDocuments.FindAsync(id);
                if (document == null)
                {
                    return Json(new { success = false, message = "Document not found" });
                }

                _context.MaintenanceDocuments.Remove(document);
                await _context.SaveChangesAsync();

                return Json(new { success = true, message = "Document deleted successfully" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
    }

    public class SaveMachinesRequest
    {
        public int CompanyId { get; set; }
        public List<Machine> Machines { get; set; }
    }
} 