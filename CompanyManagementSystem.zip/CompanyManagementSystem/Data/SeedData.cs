using Microsoft.AspNetCore.Identity;
using CompanyManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace CompanyManagementSystem.Data
{
    public static class SeedData
    {
        public static async Task Initialize(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();

            // Create roles if they don't exist
            string[] roleNames = { "Admin", "Subadmin", "User" };
            foreach (var roleName in roleNames)
            {
                if (!await roleManager.RoleExistsAsync(roleName))
                {
                    await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }

            // Create admin user
            var adminUser = new ApplicationUser
            {
                UserName = "admin@company.com",
                Email = "admin@company.com",
                FirstName = "Admin",
                LastName = "User",
                EmailConfirmed = true
            };

            string adminPassword = "Admin@123";
            var adminExists = await userManager.FindByEmailAsync(adminUser.Email);
            if (adminExists == null)
            {
                var result = await userManager.CreateAsync(adminUser, adminPassword);
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(adminUser, "Admin");
                }
            }
            else
            {
                // Ensure admin role is assigned
                var roles = await userManager.GetRolesAsync(adminExists);
                if (!roles.Contains("Admin"))
                {
                    await userManager.AddToRoleAsync(adminExists, "Admin");
                }
            }

            // Create subadmin user
            var subadminUser = new ApplicationUser
            {
                UserName = "subadmin@company.com",
                Email = "subadmin@company.com",
                FirstName = "Subadmin",
                LastName = "User",
                EmailConfirmed = true
            };

            string subadminPassword = "Subadmin@123";
            var subadminExists = await userManager.FindByEmailAsync(subadminUser.Email);
            if (subadminExists == null)
            {
                var result = await userManager.CreateAsync(subadminUser, subadminPassword);
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(subadminUser, "Subadmin");
                }
            }
            else
            {
                // Ensure subadmin role is assigned
                var roles = await userManager.GetRolesAsync(subadminExists);
                if (!roles.Contains("Subadmin"))
                {
                    await userManager.AddToRoleAsync(subadminExists, "Subadmin");
                }
            }
        }
    }
} 