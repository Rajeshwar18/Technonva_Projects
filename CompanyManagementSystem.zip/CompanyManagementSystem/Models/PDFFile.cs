using System;
using System.ComponentModel.DataAnnotations;

namespace CompanyManagementSystem.Models
{
    public class PDFFile
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string FileName { get; set; }

        [Required]
        public string FilePath { get; set; }

        public int CompanyId { get; set; }
        public Company Company { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime? UpdatedAt { get; set; }
        public string UpdatedBy { get; set; }
    }
} 