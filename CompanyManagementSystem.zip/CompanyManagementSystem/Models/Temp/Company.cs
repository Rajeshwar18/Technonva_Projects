﻿using System;
using System.Collections.Generic;

namespace CompanyManagementSystem.Models.Temp;

public partial class Company
{
    public int Id { get; set; }

    public string Address { get; set; } = null!;

    public DateTime RevisionDate { get; set; }

    public string CompanyName { get; set; } = null!;

    public string CompanyPersonName { get; set; } = null!;

    public int CompanyType { get; set; }

    public string RevisionNo { get; set; } = null!;

    public string Scope { get; set; } = null!;

    public string ShortName { get; set; } = null!;

    public string SignatureBlock { get; set; } = null!;

    public string CompanyPersonEmail { get; set; } = null!;

    public string CompanyPersonPassword { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public DateTime? LastModifiedDate { get; set; }

    public string Name { get; set; } = null!;

    public string Website { get; set; } = null!;

    public virtual ICollection<Document> Documents { get; set; } = new List<Document>();

    public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();

    public virtual ICollection<Hrdocument> Hrdocuments { get; set; } = new List<Hrdocument>();

    public virtual ICollection<Issue> Issues { get; set; } = new List<Issue>();

    public virtual ICollection<Machine> Machines { get; set; } = new List<Machine>();

    public virtual ICollection<MaintenanceDocument> MaintenanceDocuments { get; set; } = new List<MaintenanceDocument>();

    public virtual ICollection<MarketingDocument> MarketingDocuments { get; set; } = new List<MarketingDocument>();

    public virtual ICollection<Mrdocument> Mrdocuments { get; set; } = new List<Mrdocument>();

    public virtual ICollection<OrganizationChart> OrganizationCharts { get; set; } = new List<OrganizationChart>();

    public virtual ICollection<Pdffile> Pdffiles { get; set; } = new List<Pdffile>();

    public virtual ICollection<ProcessChart> ProcessCharts { get; set; } = new List<ProcessChart>();

    public virtual ICollection<PurchaseDocument> PurchaseDocuments { get; set; } = new List<PurchaseDocument>();

    public virtual ICollection<Qcdocument> Qcdocuments { get; set; } = new List<Qcdocument>();

    public virtual ICollection<StoreDocument> StoreDocuments { get; set; } = new List<StoreDocument>();
}
