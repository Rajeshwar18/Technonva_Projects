﻿using System;
using System.Collections.Generic;

namespace CompanyManagementSystem.Models.Temp;

public partial class Employee
{
    public int Id { get; set; }

    public string EmployeeId { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Designation { get; set; } = null!;

    public string Department { get; set; } = null!;

    public string Qualification { get; set; } = null!;

    public int JoiningYear { get; set; }

    public int Experience { get; set; }

    public DateTime JoinDate { get; set; }

    public string Status { get; set; } = null!;

    public int CompanyId { get; set; }

    public int Sr { get; set; }

    public virtual Company Company { get; set; } = null!;
}
