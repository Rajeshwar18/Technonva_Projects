﻿using System;
using System.Collections.Generic;

namespace CompanyManagementSystem.Models.Temp;

public partial class Document
{
    public int Id { get; set; }

    public string Code { get; set; } = null!;

    public string Title { get; set; } = null!;

    public string Version { get; set; } = null!;

    public DateTime Date { get; set; }

    public string Content { get; set; } = null!;

    public string Status { get; set; } = null!;

    public int CompanyId { get; set; }

    public virtual Company Company { get; set; } = null!;
}
