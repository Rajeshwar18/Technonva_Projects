﻿using System;
using System.Collections.Generic;

namespace CompanyManagementSystem.Models.Temp;

public partial class ProcessChart
{
    public int Id { get; set; }

    public string Content { get; set; } = null!;

    public DateTime LastUpdated { get; set; }

    public string Status { get; set; } = null!;

    public string Title { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string ImagePath { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public DateTime? LastModifiedDate { get; set; }

    public int CompanyId { get; set; }

    public virtual Company Company { get; set; } = null!;
}
