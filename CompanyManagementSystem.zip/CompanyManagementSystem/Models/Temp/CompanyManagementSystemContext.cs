﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CompanyManagementSystem.Models.Temp;

public partial class CompanyManagementSystemContext : DbContext
{
    public CompanyManagementSystemContext()
    {
    }

    public CompanyManagementSystemContext(DbContextOptions<CompanyManagementSystemContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AspNetRole> AspNetRoles { get; set; }

    public virtual DbSet<AspNetRoleClaim> AspNetRoleClaims { get; set; }

    public virtual DbSet<AspNetUser> AspNetUsers { get; set; }

    public virtual DbSet<AspNetUserClaim> AspNetUserClaims { get; set; }

    public virtual DbSet<AspNetUserLogin> AspNetUserLogins { get; set; }

    public virtual DbSet<AspNetUserToken> AspNetUserTokens { get; set; }

    public virtual DbSet<Company> Companies { get; set; }

    public virtual DbSet<Document> Documents { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<Hrdocument> Hrdocuments { get; set; }

    public virtual DbSet<Issue> Issues { get; set; }

    public virtual DbSet<Machine> Machines { get; set; }

    public virtual DbSet<MaintenanceDocument> MaintenanceDocuments { get; set; }

    public virtual DbSet<MarketingDocument> MarketingDocuments { get; set; }

    public virtual DbSet<Mrdocument> Mrdocuments { get; set; }

    public virtual DbSet<OrganizationChart> OrganizationCharts { get; set; }

    public virtual DbSet<Pdffile> Pdffiles { get; set; }

    public virtual DbSet<ProcessChart> ProcessCharts { get; set; }

    public virtual DbSet<PurchaseDocument> PurchaseDocuments { get; set; }

    public virtual DbSet<Qcdocument> Qcdocuments { get; set; }

    public virtual DbSet<StoreDocument> StoreDocuments { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=CompanyManagementSystem;Trusted_Connection=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AspNetRole>(entity =>
        {
            entity.HasIndex(e => e.NormalizedName, "RoleNameIndex")
                .IsUnique()
                .HasFilter("([NormalizedName] IS NOT NULL)");

            entity.Property(e => e.Name).HasMaxLength(256);
            entity.Property(e => e.NormalizedName).HasMaxLength(256);
        });

        modelBuilder.Entity<AspNetRoleClaim>(entity =>
        {
            entity.HasIndex(e => e.RoleId, "IX_AspNetRoleClaims_RoleId");

            entity.HasOne(d => d.Role).WithMany(p => p.AspNetRoleClaims).HasForeignKey(d => d.RoleId);
        });

        modelBuilder.Entity<AspNetUser>(entity =>
        {
            entity.HasIndex(e => e.NormalizedEmail, "EmailIndex");

            entity.HasIndex(e => e.NormalizedUserName, "UserNameIndex")
                .IsUnique()
                .HasFilter("([NormalizedUserName] IS NOT NULL)");

            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.NormalizedEmail).HasMaxLength(256);
            entity.Property(e => e.NormalizedUserName).HasMaxLength(256);
            entity.Property(e => e.UserName).HasMaxLength(256);

            entity.HasMany(d => d.Roles).WithMany(p => p.Users)
                .UsingEntity<Dictionary<string, object>>(
                    "AspNetUserRole",
                    r => r.HasOne<AspNetRole>().WithMany().HasForeignKey("RoleId"),
                    l => l.HasOne<AspNetUser>().WithMany().HasForeignKey("UserId"),
                    j =>
                    {
                        j.HasKey("UserId", "RoleId");
                        j.ToTable("AspNetUserRoles");
                        j.HasIndex(new[] { "RoleId" }, "IX_AspNetUserRoles_RoleId");
                    });
        });

        modelBuilder.Entity<AspNetUserClaim>(entity =>
        {
            entity.HasIndex(e => e.UserId, "IX_AspNetUserClaims_UserId");

            entity.HasOne(d => d.User).WithMany(p => p.AspNetUserClaims).HasForeignKey(d => d.UserId);
        });

        modelBuilder.Entity<AspNetUserLogin>(entity =>
        {
            entity.HasKey(e => new { e.LoginProvider, e.ProviderKey });

            entity.HasIndex(e => e.UserId, "IX_AspNetUserLogins_UserId");

            entity.HasOne(d => d.User).WithMany(p => p.AspNetUserLogins).HasForeignKey(d => d.UserId);
        });

        modelBuilder.Entity<AspNetUserToken>(entity =>
        {
            entity.HasKey(e => new { e.UserId, e.LoginProvider, e.Name });

            entity.HasOne(d => d.User).WithMany(p => p.AspNetUserTokens).HasForeignKey(d => d.UserId);
        });

        modelBuilder.Entity<Company>(entity =>
        {
            entity.Property(e => e.CompanyName).HasDefaultValue("");
            entity.Property(e => e.CompanyPersonEmail).HasMaxLength(100);
            entity.Property(e => e.CompanyPersonName).HasMaxLength(100);
            entity.Property(e => e.CompanyPersonPassword)
                .HasMaxLength(100)
                .HasDefaultValue("");
            entity.Property(e => e.Name)
                .HasMaxLength(200)
                .HasDefaultValue("");
            entity.Property(e => e.RevisionNo).HasMaxLength(20);
            entity.Property(e => e.Scope).HasMaxLength(500);
            entity.Property(e => e.ShortName).HasMaxLength(50);
            entity.Property(e => e.SignatureBlock).HasMaxLength(500);
            entity.Property(e => e.Website)
                .HasMaxLength(200)
                .HasDefaultValue("");
        });

        modelBuilder.Entity<Document>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_Documents_CompanyId");

            entity.Property(e => e.Code).HasMaxLength(50);
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.Property(e => e.Title).HasMaxLength(200);
            entity.Property(e => e.Version).HasMaxLength(20);

            entity.HasOne(d => d.Company).WithMany(p => p.Documents).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_Employees_CompanyId");

            entity.Property(e => e.Department).HasMaxLength(100);
            entity.Property(e => e.Designation).HasMaxLength(100);
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Qualification).HasMaxLength(100);

            entity.HasOne(d => d.Company).WithMany(p => p.Employees).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<Hrdocument>(entity =>
        {
            entity.ToTable("HRDocuments");

            entity.HasIndex(e => e.CompanyId, "IX_HRDocuments_CompanyId");

            entity.HasOne(d => d.Company).WithMany(p => p.Hrdocuments).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<Issue>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_Issues_CompanyId");

            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.Factor).HasMaxLength(200);
            entity.Property(e => e.Objective).HasMaxLength(500);
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.Property(e => e.Title).HasMaxLength(200);
            entity.Property(e => e.Type).HasMaxLength(50);

            entity.HasOne(d => d.Company).WithMany(p => p.Issues).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<Machine>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_Machines_CompanyId");

            entity.Property(e => e.Capacity).HasMaxLength(100);
            entity.Property(e => e.Code).HasMaxLength(50);
            entity.Property(e => e.Department).HasMaxLength(100);
            entity.Property(e => e.MachineName).HasMaxLength(100);
            entity.Property(e => e.Make).HasMaxLength(100);

            entity.HasOne(d => d.Company).WithMany(p => p.Machines).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<MaintenanceDocument>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_MaintenanceDocuments_CompanyId");

            entity.HasOne(d => d.Company).WithMany(p => p.MaintenanceDocuments).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<MarketingDocument>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_MarketingDocuments_CompanyId");

            entity.HasOne(d => d.Company).WithMany(p => p.MarketingDocuments).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<Mrdocument>(entity =>
        {
            entity.ToTable("MRDocuments");

            entity.HasIndex(e => e.CompanyId, "IX_MRDocuments_CompanyId");

            entity.HasOne(d => d.Company).WithMany(p => p.Mrdocuments).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<OrganizationChart>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_OrganizationCharts_CompanyId");

            entity.HasOne(d => d.Company).WithMany(p => p.OrganizationCharts).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<Pdffile>(entity =>
        {
            entity.ToTable("PDFFiles");

            entity.HasIndex(e => e.CompanyId, "IX_PDFFiles_CompanyId");

            entity.HasOne(d => d.Company).WithMany(p => p.Pdffiles).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<ProcessChart>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_ProcessCharts_CompanyId");

            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.Property(e => e.Title).HasMaxLength(200);

            entity.HasOne(d => d.Company).WithMany(p => p.ProcessCharts).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<PurchaseDocument>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_PurchaseDocuments_CompanyId");

            entity.HasOne(d => d.Company).WithMany(p => p.PurchaseDocuments).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<Qcdocument>(entity =>
        {
            entity.ToTable("QCDocuments");

            entity.HasIndex(e => e.CompanyId, "IX_QCDocuments_CompanyId");

            entity.HasOne(d => d.Company).WithMany(p => p.Qcdocuments).HasForeignKey(d => d.CompanyId);
        });

        modelBuilder.Entity<StoreDocument>(entity =>
        {
            entity.HasIndex(e => e.CompanyId, "IX_StoreDocuments_CompanyId");

            entity.HasOne(d => d.Company).WithMany(p => p.StoreDocuments).HasForeignKey(d => d.CompanyId);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
