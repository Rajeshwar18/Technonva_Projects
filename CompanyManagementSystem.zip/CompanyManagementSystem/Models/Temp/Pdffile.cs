﻿using System;
using System.Collections.Generic;

namespace CompanyManagementSystem.Models.Temp;

public partial class Pdffile
{
    public int Id { get; set; }

    public string FileName { get; set; } = null!;

    public string FilePath { get; set; } = null!;

    public int CompanyId { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public string UpdatedBy { get; set; } = null!;

    public DateTime UploadDate { get; set; }

    public virtual Company Company { get; set; } = null!;
}
