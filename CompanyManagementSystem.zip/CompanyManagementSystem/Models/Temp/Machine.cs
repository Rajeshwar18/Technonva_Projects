﻿using System;
using System.Collections.Generic;

namespace CompanyManagementSystem.Models.Temp;

public partial class Machine
{
    public int Id { get; set; }

    public int Sr { get; set; }

    public string Code { get; set; } = null!;

    public string MachineName { get; set; } = null!;

    public string Make { get; set; } = null!;

    public string Capacity { get; set; } = null!;

    public string Department { get; set; } = null!;

    public int CompanyId { get; set; }

    public DateTime CreatedDate { get; set; }

    public DateTime? LastModifiedDate { get; set; }

    public string? Parameters { get; set; }

    public string? DailySchedule { get; set; }

    public string? WeeklySchedule { get; set; }

    public string? MonthlySchedule { get; set; }

    public virtual Company Company { get; set; } = null!;
}
