using System;
using System.ComponentModel.DataAnnotations;

namespace CompanyManagementSystem.Models
{
    public class Machine
    {
        public int Id { get; set; }

        [Required]
        public int Sr { get; set; }

        [Required]
        public string Code { get; set; } = string.Empty;

        [Required]
        public string MachineName { get; set; } = string.Empty;

        [Required]
        public string Make { get; set; } = string.Empty;

        [Required]
        public string Capacity { get; set; } = string.Empty;

        [Required]
        public string Department { get; set; } = string.Empty;

        // Maintenance Schedule Fields
        public string? Parameters { get; set; }
        public string? DailySchedule { get; set; }
        public string? WeeklySchedule { get; set; }
        public string? MonthlySchedule { get; set; }

        public int CompanyId { get; set; }
        public Company? Company { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public DateTime? LastModifiedDate { get; set; }
    }
} 