using System;
using System.Collections.Generic;

namespace CompanyManagementSystem.Models
{
    public class EmployeeDataViewModel
    {
        public int CompanyId { get; set; }
        public List<EmployeeFormData> Employees { get; set; }
    }

    public class EmployeeFormData
    {
        public int Sr { get; set; }
        public string Name { get; set; }
        public string Designation { get; set; }
        public string Department { get; set; }
        public string Qualification { get; set; }
        public string JoinDate { get; set; }
        public int JoiningYear { get; set; }
        public int Experience { get; set; }
        public string Status { get; set; }
    }
} 