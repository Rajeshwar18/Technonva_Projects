using System;

namespace CompanyManagementSystem.Models
{
    public class MaintenanceDocument : BaseDocument
    {
        public string DocumentType { get; set; }
        public string WorkDone { get; set; }
        public string PartsReplaced { get; set; }
        public string MaintenanceBy { get; set; }
        public DateTime? MaintenanceDate { get; set; }
        public decimal? TotalHours { get; set; }
        public string SupervisorSign { get; set; }
        public string Time { get; set; }
        public int? MachineId { get; set; }
        public Machine Machine { get; set; }
    }
} 