using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using CompanyManagementSystem.Models;

namespace CompanyManagementSystem.Models.ViewModels
{
    public class CompanyViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Company name is required")]
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }

        [Required(ErrorMessage = "Short name is required")]
        [Display(Name = "Short Name")]
        public string ShortName { get; set; }

        [Required(ErrorMessage = "Company type is required")]
        [Display(Name = "Company Type")]
        public CompanyType CompanyType { get; set; }

        [Required(ErrorMessage = "Scope is required")]
        public string Scope { get; set; }

        [Required(ErrorMessage = "Address is required")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Company person name is required")]
        [Display(Name = "Company Person Name")]
        public string CompanyPersonName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        [Display(Name = "Company Person Email")]
        public string CompanyPersonEmail { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [Display(Name = "Company Person Password")]
        public string CompanyPersonPassword { get; set; }

        [Required(ErrorMessage = "Revision number is required")]
        [Display(Name = "Revision Number")]
        public string RevisionNo { get; set; }

        [Required(ErrorMessage = "Revision date is required")]
        [Display(Name = "Revision Date")]
        [DataType(DataType.Date)]
        public DateTime RevisionDate { get; set; }

        [Display(Name = "Signature 1")]
        public IFormFile Signature1 { get; set; }

        [Display(Name = "Signature 2")]
        public IFormFile Signature2 { get; set; }
    }
} 