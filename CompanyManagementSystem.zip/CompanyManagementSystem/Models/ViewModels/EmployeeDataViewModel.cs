using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CompanyManagementSystem.Models.ViewModels
{
    public class EmployeeDataViewModel
    {
        [Required]
        public int CompanyId { get; set; }

        [Required]
        public List<EmployeeData> Employees { get; set; }
    }

    public class EmployeeData
    {
        public int Sr { get; set; }
        
        [Required]
        public string Name { get; set; }
        
        [Required]
        public string Designation { get; set; }
        
        [Required]
        public string Department { get; set; }
        
        [Required]
        public string Qualification { get; set; }
        
        [Required]
        public string JoinDate { get; set; }
        
        [Required]
        public int JoiningYear { get; set; }
        
        [Required]
        public int Experience { get; set; }
        
        [Required]
        public string Status { get; set; }
    }
} 