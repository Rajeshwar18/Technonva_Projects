using System;

namespace CompanyManagementSystem.Models
{
    public class PurchaseDocument : BaseDocument
    {
        public string DocumentType { get; set; }
    }
} 