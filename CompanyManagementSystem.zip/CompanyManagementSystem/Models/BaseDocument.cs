using System;
using System.ComponentModel.DataAnnotations;

namespace CompanyManagementSystem.Models
{
    public abstract class BaseDocument
    {
        public int Id { get; set; }

        [Required]
        public string Code { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Version { get; set; }

        public DateTime Date { get; set; }

        [Required]
        public string Content { get; set; }

        [Required]
        public string Status { get; set; }

        public int CompanyId { get; set; }
        public Company Company { get; set; }
    }
} 