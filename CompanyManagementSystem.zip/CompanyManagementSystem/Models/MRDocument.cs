using System;

namespace CompanyManagementSystem.Models
{
    public class MRDocument : BaseDocument
    {
        public string DocumentType { get; set; }
    }
} 