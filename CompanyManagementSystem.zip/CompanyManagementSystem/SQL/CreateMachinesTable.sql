-- Create Machines table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Machines]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[Machines] (
        [Id] INT IDENTITY(1,1) NOT NULL,
        [Sr] INT NOT NULL,
        [Code] NVARCHAR(50) NOT NULL,
        [MachineName] NVARCHAR(100) NOT NULL,
        [Make] NVARCHAR(100) NOT NULL,
        [Capacity] NVARCHAR(100) NOT NULL,
        [Department] NVARCHAR(100) NOT NULL,
        [CompanyId] INT NOT NULL,
        [CreatedDate] DATETIME2 NOT NULL DEFAULT GETDATE(),
        [LastModifiedDate] DATETIME2 NULL,
        CONSTRAINT [PK_Machines] PRIMARY KEY CLUSTERED ([Id] ASC),
        CONSTRAINT [FK_Machines_Companies_CompanyId] FOREIGN KEY ([CompanyId]) 
            REFERENCES [dbo].[Companies] ([Id]) 
            ON DELETE CASCADE
    )
END
GO

-- Create index for better performance
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Machines]') AND name = N'IX_Machines_CompanyId')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_Machines_CompanyId] ON [dbo].[Machines]([CompanyId] ASC)
END
GO

-- Add Machines relationship to Companies table if not exists
IF NOT EXISTS (
    SELECT * 
    FROM sys.foreign_keys 
    WHERE object_id = OBJECT_ID(N'[dbo].[FK_Machines_Companies_CompanyId]')
)
BEGIN
    ALTER TABLE [dbo].[Machines]
    ADD CONSTRAINT [FK_Machines_Companies_CompanyId]
    FOREIGN KEY ([CompanyId]) REFERENCES [dbo].[Companies] ([Id])
    ON DELETE CASCADE
END
GO 