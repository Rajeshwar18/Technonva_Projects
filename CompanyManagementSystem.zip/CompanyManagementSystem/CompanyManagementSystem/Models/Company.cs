using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CompanyManagementSystem.Models
{
    public class Company
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string CompanyName { get; set; }

        [Required]
        public string ShortName { get; set; }

        [Required]
        public CompanyType CompanyType { get; set; }

        [Required]
        public string Scope { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public string CompanyPersonName { get; set; }

        [Required]
        [EmailAddress]
        public string CompanyPersonEmail { get; set; }

        [Required]
        public string CompanyPersonPassword { get; set; }

        [Required]
        public string Website { get; set; }

        [Required]
        public string RevisionNo { get; set; }

        [Required]
        public DateTime RevisionDate { get; set; }

        [Required]
        public string SignatureBlock { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? LastModifiedDate { get; set; }

        public virtual ICollection<HRDocument> HRDocuments { get; set; }
        public virtual ICollection<MRDocument> MRDocuments { get; set; }
        public virtual ICollection<MarketingDocument> MarketingDocuments { get; set; }
        public virtual ICollection<PurchaseDocument> PurchaseDocuments { get; set; }
        public virtual ICollection<MaintenanceDocument> MaintenanceDocuments { get; set; }
        public virtual ICollection<StoreDocument> StoreDocuments { get; set; }
        public virtual ICollection<QCDocument> QCDocuments { get; set; }
        public virtual ICollection<PDFFile> PDFFiles { get; set; }
        public virtual ICollection<ProcessChart> ProcessCharts { get; set; }
        public virtual ICollection<OrganizationChart> OrganizationCharts { get; set; }
        public virtual ICollection<Issue> Issues { get; set; }
        public virtual ICollection<Employee> Employees { get; set; }
    }

    public enum CompanyType
    {
        PrivateLimited,
        LLB,
        Proprietorship,
        Vendors
    }
} 