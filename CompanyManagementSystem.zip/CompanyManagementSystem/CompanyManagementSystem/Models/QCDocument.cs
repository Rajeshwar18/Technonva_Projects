using System;

namespace CompanyManagementSystem.Models
{
    public class QCDocument : BaseDocument
    {
        public string DocumentType { get; set; }
    }
} 