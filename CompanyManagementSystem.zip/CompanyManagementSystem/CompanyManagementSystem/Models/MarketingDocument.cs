using System;

namespace CompanyManagementSystem.Models
{
    public class MarketingDocument : BaseDocument
    {
        public string DocumentType { get; set; }
    }
} 