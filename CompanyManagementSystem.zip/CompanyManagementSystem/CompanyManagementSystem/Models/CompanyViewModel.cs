using System.ComponentModel.DataAnnotations;

namespace CompanyManagementSystem.Models
{
    public class CompanyViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Company Name is required")]
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }

        [Required(ErrorMessage = "Address is required")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Scope is required")]
        public string Scope { get; set; }

        [Required(ErrorMessage = "Revision Number is required")]
        [Display(Name = "Revision Number")]
        public string RevisionNo { get; set; }

        [Required(ErrorMessage = "Revision Date is required")]
        [Display(Name = "Revision Date")]
        [DataType(DataType.Date)]
        public DateTime RevisionDate { get; set; }

        [Required(ErrorMessage = "Company Person Name is required")]
        [Display(Name = "Company Person Name")]
        public string CompanyPersonName { get; set; }

        [Required(ErrorMessage = "Company Person Email is required")]
        [Display(Name = "Company Person Email")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string CompanyPersonEmail { get; set; }

        [Required(ErrorMessage = "Company Person Password is required")]
        [Display(Name = "Company Person Password")]
        [DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        public string CompanyPersonPassword { get; set; }

        [Required(ErrorMessage = "Company Type is required")]
        [Display(Name = "Company Type")]
        public CompanyType CompanyType { get; set; }

        [Required(ErrorMessage = "Short Name is required")]
        [Display(Name = "Short Name")]
        public string ShortName { get; set; }

        [Required(ErrorMessage = "Signature Block is required")]
        [Display(Name = "Signature Block")]
        public string SignatureBlock { get; set; }
    }
} 