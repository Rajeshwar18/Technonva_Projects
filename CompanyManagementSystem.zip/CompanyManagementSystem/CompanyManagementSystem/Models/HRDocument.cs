using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CompanyManagementSystem.Models
{
    public class HRDocument : BaseDocument
    {
        // No need to redefine properties that are already in BaseDocument
        // The base class already contains: Code, Title, Version, Date, Content, Status, CompanyId, and Company
    }
} 