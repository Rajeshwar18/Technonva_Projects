using System.Collections.Generic;

namespace CompanyManagementSystem.Models
{
    public class EmployeeDataViewModel
    {
        public int CompanyId { get; set; }
        public List<Employee> Employees { get; set; }
    }
} 