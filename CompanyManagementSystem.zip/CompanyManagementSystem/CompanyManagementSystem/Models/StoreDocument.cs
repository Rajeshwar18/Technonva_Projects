using System;

namespace CompanyManagementSystem.Models
{
    public class StoreDocument : BaseDocument
    {
        public string DocumentType { get; set; }
    }
} 