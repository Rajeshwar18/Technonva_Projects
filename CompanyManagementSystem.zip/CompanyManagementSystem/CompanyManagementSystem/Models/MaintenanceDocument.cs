using System;

namespace CompanyManagementSystem.Models
{
    public class MaintenanceDocument : BaseDocument
    {
        public string DocumentType { get; set; }
    }
} 