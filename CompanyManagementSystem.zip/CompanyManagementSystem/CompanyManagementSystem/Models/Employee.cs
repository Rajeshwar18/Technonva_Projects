using System;
using System.ComponentModel.DataAnnotations;

namespace CompanyManagementSystem.Models
{
    public class Employee
    {
        public int Id { get; set; }

        [Required]
        public string EmployeeId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Designation { get; set; }

        [Required]
        public string Department { get; set; }

        [Required]
        public string Qualification { get; set; }

        [Required]
        public int JoiningYear { get; set; }

        [Required]
        public int Experience { get; set; }

        public DateTime JoinDate { get; set; }

        [Required]
        public string Status { get; set; }

        public int CompanyId { get; set; }
        public Company Company { get; set; }
    }
} 