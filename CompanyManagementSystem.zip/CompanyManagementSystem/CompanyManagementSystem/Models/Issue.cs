using System;
using System.ComponentModel.DataAnnotations;

namespace CompanyManagementSystem.Models
{
    public class Issue
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Type { get; set; } = string.Empty;

        [Required]
        [MaxLength(200)]
        public string Factor { get; set; } = string.Empty;

        [Required]
        [MaxLength(500)]
        public string Objective { get; set; } = string.Empty;

        [Required]
        [MaxLength(200)]
        public string Title { get; set; } = string.Empty;

        [MaxLength(500)]
        public string Description { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Status { get; set; } = string.Empty;

        public int CompanyId { get; set; }
        public Company Company { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
    }
} 