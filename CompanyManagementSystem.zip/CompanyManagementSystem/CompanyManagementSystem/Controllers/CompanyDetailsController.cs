using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompanyManagementSystem.Data;
using CompanyManagementSystem.Models;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Collections.Generic;

namespace CompanyManagementSystem.Controllers
{
    [Authorize(Roles = "Admin")]
    public class CompanyDetailsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CompanyDetailsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(int id)
        {
            var company = await _context.Companies
                .Include(c => c.HRDocuments)
                .Include(c => c.Issues)
                .Include(c => c.Employees)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View(company);
        }

        public async Task<IActionResult> HR(int id)
        {
            var company = await _context.Companies
                .Include(c => c.HRDocuments)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.Name;
            return View(company);
        }

        public async Task<IActionResult> DHR01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.HRDocuments.Where(d => d.Code.StartsWith("DHR01")))
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            ViewBag.Documents = company.HRDocuments?.ToList() ?? new List<HRDocument>();
            return View("~/Views/CompanyDetails/HR/DHR01.cshtml", company);
        }

        public async Task<IActionResult> DHR02(int id)
        {
            var company = await _context.Companies
                .Include(c => c.Issues)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            ViewBag.Issues = company.Issues?.ToList() ?? new List<Issue>();
            return View("~/Views/CompanyDetails/HR/DHR02.cshtml", company);
        }

        public async Task<IActionResult> FHR01(int id)
        {
            var company = await _context.Companies
                .Include(c => c.Employees)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            ViewBag.Employees = company.Employees?.ToList() ?? new List<Employee>();
            return View("~/Views/CompanyDetails/HR/FHR01.cshtml", company);
        }

        public async Task<IActionResult> Form(int id)
        {
            var company = await _context.Companies
                .Include(c => c.Employees)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            ViewBag.Employees = company.Employees?.ToList() ?? new List<Employee>();
            return View("~/Views/CompanyDetails/HR/Form.cshtml", company);
        }

        public async Task<IActionResult> PCMR03(int id)
        {
            var company = await _context.Companies
                .Include(c => c.ProcessCharts)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            ViewBag.ProcessCharts = company.ProcessCharts?.ToList() ?? new List<ProcessChart>();
            return View("~/Views/CompanyDetails/HR/PCMR03.cshtml", company);
        }

        [HttpPost]
        public async Task<IActionResult> SaveDocument(Document document)
        {
            try
            {
                if (document.Id == 0)
                {
                    document.Date = DateTime.Now;
                    _context.Documents.Add(document);
                }
                else
                {
                    var existingDoc = await _context.Documents.FindAsync(document.Id);
                    if (existingDoc == null)
                    {
                        return NotFound();
                    }
                    existingDoc.Title = document.Title;
                    existingDoc.Version = document.Version;
                    existingDoc.Content = document.Content;
                    existingDoc.Status = document.Status;
                }

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Document saved successfully.";
                return RedirectToAction(nameof(DHR01), new { id = document.CompanyId });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error saving document: " + ex.Message;
                return RedirectToAction(nameof(DHR01), new { id = document.CompanyId });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteDocument(int id)
        {
            var document = await _context.Documents.FindAsync(id);
            if (document == null)
            {
                return NotFound();
            }

            _context.Documents.Remove(document);
            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> SaveIssue(Issue issue)
        {
            try
            {
                if (issue.Id == 0)
                {
                    issue.CreatedDate = DateTime.Now;
                    _context.Issues.Add(issue);
                }
                else
                {
                    var existingIssue = await _context.Issues.FindAsync(issue.Id);
                    if (existingIssue == null)
                    {
                        return NotFound();
                    }
                    existingIssue.Type = issue.Type;
                    existingIssue.Factor = issue.Factor;
                    existingIssue.Objective = issue.Objective;
                }

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Issue saved successfully.";
                return RedirectToAction(nameof(DHR02), new { id = issue.CompanyId });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error saving issue: " + ex.Message;
                return RedirectToAction(nameof(DHR02), new { id = issue.CompanyId });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteIssue(int id)
        {
            var issue = await _context.Issues.FindAsync(id);
            if (issue == null)
            {
                return NotFound();
            }

            _context.Issues.Remove(issue);
            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> SaveEmployee(Employee employee)
        {
            try
            {
                if (employee.Id == 0)
                {
                    _context.Employees.Add(employee);
                }
                else
                {
                    var existingEmployee = await _context.Employees.FindAsync(employee.Id);
                    if (existingEmployee == null)
                    {
                        return NotFound();
                    }
                    existingEmployee.Name = employee.Name;
                    existingEmployee.Designation = employee.Designation;
                    existingEmployee.Qualification = employee.Qualification;
                    existingEmployee.JoiningYear = employee.JoiningYear;
                    existingEmployee.Experience = employee.Experience;
                }

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Employee saved successfully.";
                return RedirectToAction(nameof(Form), new { id = employee.CompanyId });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error saving employee: " + ex.Message;
                return RedirectToAction(nameof(Form), new { id = employee.CompanyId });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }

            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> SaveEmployeeData([FromBody] EmployeeDataViewModel model)
        {
            try
            {
                foreach (var employee in model.Employees)
                {
                    employee.CompanyId = model.CompanyId;
                    _context.Employees.Add(employee);
                }
                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> SaveProcessChart([FromBody] ProcessChart chart)
        {
            try
            {
                chart.LastUpdated = DateTime.Now;
                _context.ProcessCharts.Add(chart);
                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetProcessChart(int id)
        {
            try
            {
                var chart = await _context.ProcessCharts
                    .FirstOrDefaultAsync(p => p.Id == id);

                if (chart == null)
                {
                    return Json(new { success = false, message = "Chart not found" });
                }

                return Json(new { success = true, data = chart });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteProcessChart(int id, int companyId)
        {
            try
            {
                var chart = await _context.ProcessCharts
                    .FirstOrDefaultAsync(p => p.Id == id && p.CompanyId == companyId);

                if (chart == null)
                {
                    return Json(new { success = false, message = "Chart not found" });
                }

                _context.ProcessCharts.Remove(chart);
                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public async Task<IActionResult> MR(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View();
        }

        public async Task<IActionResult> Marketing(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View();
        }

        public async Task<IActionResult> Purchase(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View();
        }

        public async Task<IActionResult> Maintenance(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View();
        }

        public async Task<IActionResult> Maintenance1(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View();
        }

        public async Task<IActionResult> Store(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View();
        }

        public async Task<IActionResult> QC(int id)
        {
            var company = await _context.Companies
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View();
        }

        public async Task<IActionResult> PDFFiles(int id)
        {
            var company = await _context.Companies
                .Include(c => c.PDFFiles)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
            {
                return NotFound();
            }

            ViewBag.CompanyId = id;
            ViewBag.CompanyName = company.CompanyName;
            return View(company.PDFFiles);
        }
    }
} 