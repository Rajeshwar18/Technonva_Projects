using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using CompanyManagementSystem.Models;

namespace CompanyManagementSystem.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Company> Companies { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<HRDocument> HRDocuments { get; set; }
        public DbSet<MRDocument> MRDocuments { get; set; }
        public DbSet<MarketingDocument> MarketingDocuments { get; set; }
        public DbSet<PurchaseDocument> PurchaseDocuments { get; set; }
        public DbSet<MaintenanceDocument> MaintenanceDocuments { get; set; }
        public DbSet<StoreDocument> StoreDocuments { get; set; }
        public DbSet<QCDocument> QCDocuments { get; set; }
        public DbSet<PDFFile> PDFFiles { get; set; }
        public DbSet<ProcessChart> ProcessCharts { get; set; }
        public DbSet<OrganizationChart> OrganizationCharts { get; set; }
        public DbSet<Issue> Issues { get; set; }
        public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure ApplicationUser
            builder.Entity<ApplicationUser>(entity =>
            {
                entity.Property(e => e.FirstName).HasMaxLength(100);
                entity.Property(e => e.LastName).HasMaxLength(100);
                entity.Property(e => e.CompanyId).IsRequired(false);
            });

            // Configure Company
            builder.Entity<Company>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
                entity.Property(e => e.ShortName).HasMaxLength(50);
                entity.Property(e => e.CompanyType).HasMaxLength(50);
                entity.Property(e => e.Scope).HasMaxLength(500);
                entity.Property(e => e.CompanyPersonName).HasMaxLength(100);
                entity.Property(e => e.CompanyPersonEmail).HasMaxLength(100);
                entity.Property(e => e.CompanyPersonPassword).HasMaxLength(100);
                entity.Property(e => e.Website).HasMaxLength(200);
                entity.Property(e => e.RevisionNo).HasMaxLength(20);
                entity.Property(e => e.SignatureBlock).HasMaxLength(500);
            });

            // Configure Document
            builder.Entity<Document>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Code).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Version).HasMaxLength(20);
                entity.Property(e => e.Status).HasMaxLength(50);
            });

            // Configure ProcessChart
            builder.Entity<ProcessChart>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.Status).HasMaxLength(50);
            });

            // Configure Issue
            builder.Entity<Issue>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.Status).HasMaxLength(50);
            });

            // Configure Employee
            builder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Designation).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Qualification).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Department).HasMaxLength(100);
            });

            // Configure relationships
            builder.Entity<Company>()
                .HasMany(c => c.HRDocuments)
                .WithOne(d => d.Company)
                .HasForeignKey(d => d.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.MRDocuments)
                .WithOne(d => d.Company)
                .HasForeignKey(d => d.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.MarketingDocuments)
                .WithOne(d => d.Company)
                .HasForeignKey(d => d.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.PurchaseDocuments)
                .WithOne(d => d.Company)
                .HasForeignKey(d => d.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.MaintenanceDocuments)
                .WithOne(d => d.Company)
                .HasForeignKey(d => d.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.StoreDocuments)
                .WithOne(d => d.Company)
                .HasForeignKey(d => d.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.QCDocuments)
                .WithOne(d => d.Company)
                .HasForeignKey(d => d.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.PDFFiles)
                .WithOne(p => p.Company)
                .HasForeignKey(p => p.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.ProcessCharts)
                .WithOne(p => p.Company)
                .HasForeignKey(p => p.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.OrganizationCharts)
                .WithOne(o => o.Company)
                .HasForeignKey(o => o.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.Issues)
                .WithOne(i => i.Company)
                .HasForeignKey(i => i.CompanyId);

            builder.Entity<Company>()
                .HasMany(c => c.Employees)
                .WithOne(e => e.Company)
                .HasForeignKey(e => e.CompanyId);
        }
    }
} 