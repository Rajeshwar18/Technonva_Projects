﻿namespace AspnetIdentityRoleBasedTutorial.Constants
{
    public enum Roles
    {
        Admin,
        SubAdmin,
        User
    }
    public class MyConstants
    {
    }
}
