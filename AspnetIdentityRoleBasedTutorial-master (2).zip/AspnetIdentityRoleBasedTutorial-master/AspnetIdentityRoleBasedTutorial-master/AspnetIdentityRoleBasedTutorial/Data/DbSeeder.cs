﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;
using AspnetIdentityRoleBasedTutorial.Data;
using AspnetIdentityRoleBasedTutorial.Constants;

namespace AspnetIdentityRoleBasedTutorial.Data
{
    public static class DbSeeder
    {
        public static async Task SeedRolesAndAdminAsync(IServiceProvider serviceProvider)
        {
            // Get required services from the service provider
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();

            // Seed roles
            string[] roleNames = { Roles.Admin.ToString(), Roles.SubAdmin.ToString(), Roles.User.ToString() };
            foreach (var roleName in roleNames)
            {
                // Check if the role already exists
                var roleExist = await roleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    // Create the role if it doesn't exist
                    await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }

            // Seed admin user
            var adminUser = new ApplicationUser
            {
                UserName = "admin@gmail.com",
                Email = "admin@gmail.com",
                Name = "Admin User",
                EmailConfirmed = true,
                PhoneNumberConfirmed = true
            };

            // Check if the admin user already exists
            var adminUserInDb = await userManager.FindByEmailAsync(adminUser.Email);
            if (adminUserInDb == null)
            {
                // Create the admin user if it doesn't exist
                var createAdminUser = await userManager.CreateAsync(adminUser, "Admin@123");
                if (createAdminUser.Succeeded)
                {
                    // Assign the Admin role to the admin user
                    await userManager.AddToRoleAsync(adminUser, Roles.Admin.ToString());
                }
            }

            // Seed subadmin user
            var subAdminUser = new ApplicationUser
            {
                UserName = "subadmin@gmail.com",
                Email = "subadmin@gmail.com",
                Name = "SubAdmin User",
                EmailConfirmed = true,
                PhoneNumberConfirmed = true
            };

            // Check if the subadmin user already exists
            var subAdminUserInDb = await userManager.FindByEmailAsync(subAdminUser.Email);
            if (subAdminUserInDb == null)
            {
                // Create the subadmin user if it doesn't exist
                var createSubAdminUser = await userManager.CreateAsync(subAdminUser, "SubAdmin@123");
                if (createSubAdminUser.Succeeded)
                {
                    // Assign the SubAdmin role to the subadmin user
                    await userManager.AddToRoleAsync(subAdminUser, Roles.SubAdmin.ToString());
                }
            }

            // Seed regular user (optional)
            var regularUser = new ApplicationUser
            {
                UserName = "user@gmail.com",
                Email = "user@gmail.com",
                Name = "Regular User",
                EmailConfirmed = true,
                PhoneNumberConfirmed = true
            };

            // Check if the regular user already exists
            var regularUserInDb = await userManager.FindByEmailAsync(regularUser.Email);
            if (regularUserInDb == null)
            {
                // Create the regular user if it doesn't exist
                var createRegularUser = await userManager.CreateAsync(regularUser, "User@123");
                if (createRegularUser.Succeeded)
                {
                    // Assign the User role to the regular user
                    await userManager.AddToRoleAsync(regularUser, Roles.User.ToString());
                }
            }
        }
    }
}