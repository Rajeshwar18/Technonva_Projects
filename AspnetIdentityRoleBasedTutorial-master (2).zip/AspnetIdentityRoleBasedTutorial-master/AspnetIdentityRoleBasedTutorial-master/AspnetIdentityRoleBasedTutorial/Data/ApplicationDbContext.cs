﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AspnetIdentityRoleBasedTutorial.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        internal object products;

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // Add DbSet for Product
        public DbSet<Product> Products { get; set; } // Ensure the property name matches

        // Add DbSet for CompanyInventory
        public DbSet<CompanyInventory> CompanyInventory { get; set; }
    }
}